package com.chameleon.client;

import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * HATA #5 DÜZELTMESİ — HUD yalnızca sunucu varken gösteriliyor.
 * HATA #8 DÜZELTMESİ — Ölü değişken "GameClientState gs = null" kaldırıldı.
 *
 * Önceki kod: stateId=0 olduğunda (yani her zaman, sunucu olmasa bile)
 *             ekranın altına "Oyun bekleniyor..." yazısı çiziyordu.
 *
 * serverPresent flag'i: ilk GAME_STATE paketi geldiğinde true olur.
 * ChameleonClient, GAME_STATE aldığında bu flag'i set eder.
 * Oyun dünyasından çıkılınca (disconnect) sıfırlanır.
 */
@Environment(EnvType.CLIENT)
public class GameHudOverlay {

    /** Sunucudan en az bir GAME_STATE paketi geldi mi? */
    public static boolean serverPresent = false;

    private static final int BAR_W = 200;
    private static final int BAR_H = 8;

    public static void render(DrawContext ctx, MinecraftClient client, float tickDelta) {
        // HATA #5: sunucu yoksa HUD gösterme
        if (!serverPresent) return;
        if (client.player == null || client.options.hudHidden) return;

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();
        TextRenderer tr = client.textRenderer;

        // HATA #8: "GameClientState gs = null" ölü değişken kaldırıldı
        switch (GameClientState.stateId) {
            case 0, 1 -> renderWaiting(ctx, tr, sw, sh);
            case 2    -> renderCountdown(ctx, tr, sw, sh);
            case 3    -> renderHiding(ctx, tr, sw, sh, client);
            case 4    -> renderSeeking(ctx, tr, sw, sh, client);
            case 5    -> renderEnded(ctx, tr, sw, sh);
        }

        renderCaughtNotice(ctx, tr, sw);
    }

    private static void renderWaiting(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        String line2 = GameClientState.timerSeconds > 0
                ? "§aOyun §e" + GameClientState.timerSeconds + "s §aiçinde başlıyor!"
                : "§7Daha fazla oyuncu bekleniyor.";
        ctx.drawCenteredTextWithShadow(tr, "§7Oyun bekleniyor...", sw / 2, sh - 60, 0xAAAAAA);
        ctx.drawCenteredTextWithShadow(tr, line2, sw / 2, sh - 48, 0xFFFFFF);
    }

    private static void renderCountdown(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        int secs = GameClientState.timerSeconds;
        String num = secs <= 3 ? "§c" + secs : "§e" + secs;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(sw / 2f, sh / 2f - 20, 0);
        ctx.getMatrices().scale(3f, 3f, 1f);
        ctx.drawCenteredTextWithShadow(tr, num, 0, 0, 0xFFFFFF);
        ctx.getMatrices().pop();
        ctx.drawCenteredTextWithShadow(tr, "§7Oyun başlıyor...", sw / 2, sh / 2 + 24, 0xAAAAAA);
    }

    private static void renderHiding(DrawContext ctx, TextRenderer tr, int sw, int sh,
                                      MinecraftClient client) {
        boolean isSeeker = client.player != null &&
                RoleManager.isSeeker(client.player.getUuid());
        ctx.drawTextWithShadow(tr,
                isSeeker ? "§c👁 GÖZLER KAPALI" : "§a🏃 SAKLANMA FAZI", 8, 8, 0xFFFFFF);
        int secs = GameClientState.timerSeconds;
        renderTimerBar(ctx, sw, 20, Math.min(1f, secs / 60f),
                isSeeker ? 0xFFFF4444 : 0xFF44FF44, formatTime(secs));
        ctx.drawCenteredTextWithShadow(tr,
                isSeeker ? "§7Saklananlar hazırlanıyor..." : "§7İyi bir yer bul!",
                sw / 2, sh - 40, 0xCCCCCC);
    }

    private static void renderSeeking(DrawContext ctx, TextRenderer tr, int sw, int sh,
                                       MinecraftClient client) {
        boolean isSeeker = client.player != null &&
                RoleManager.isSeeker(client.player.getUuid());
        ctx.drawTextWithShadow(tr,
                isSeeker ? "§c🏹 ARAMA FAZI" : "§a😶 GİZLEN!", 8, 8, 0xFFFFFF);
        int secs = GameClientState.timerSeconds;
        renderTimerBar(ctx, sw, 20, Math.min(1f, secs / 300f),
                isSeeker ? 0xFFFF6644 : 0xFF4488FF, formatTime(secs));
        ctx.drawCenteredTextWithShadow(tr,
                "§aSaklanan: §f" + GameClientState.hidersAlive +
                " §7/ §f" + GameClientState.totalHiders,
                sw / 2, 36, 0xFFFFFF);
        if (secs <= 30 && secs > 0)
            ctx.drawCenteredTextWithShadow(tr, "§c⚠ " + secs + "s kaldı!",
                    sw / 2, sh - 40, 0xFF4444);
    }

    private static void renderEnded(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        ctx.fill(sw/2-120, sh/2-30, sw/2+120, sh/2+20, 0xAA000000);
        ctx.drawCenteredTextWithShadow(tr, "§6🏆 OYUN BİTTİ", sw/2, sh/2-22, 0xFFAA00);
        ctx.drawCenteredTextWithShadow(tr,
                GameClientState.winnerText + " §6KAZANDI!", sw/2, sh/2-6, 0xFFFFFF);
    }

    private static void renderCaughtNotice(DrawContext ctx, TextRenderer tr, int sw) {
        if (GameClientState.caughtPlayerName.isEmpty()) return;
        long ago = System.currentTimeMillis() - GameClientState.caughtAt;
        if (ago > 4000) { GameClientState.caughtPlayerName = ""; return; }
        float alpha = ago < 3000 ? 1f : 1f - (ago - 3000) / 1000f;
        int a = (int)(alpha * 200) << 24;
        ctx.drawCenteredTextWithShadow(tr,
                "§c💥 §f" + GameClientState.caughtPlayerName + " §7yakalandı!",
                sw / 2, 60, a | 0xFFFFFF);
    }

    private static void renderTimerBar(DrawContext ctx, int sw, int y,
                                        float pct, int color, String label) {
        int bx = (sw - BAR_W) / 2;
        ctx.fill(bx-1, y-1, bx+BAR_W+1, y+BAR_H+1, 0xFF111111);
        ctx.fill(bx, y, bx+(int)(pct*BAR_W), y+BAR_H, color);
        ctx.fill(bx+(int)(pct*BAR_W), y, bx+BAR_W, y+BAR_H, 0xFF333333);
        ctx.drawCenteredTextWithShadow(
                MinecraftClient.getInstance().textRenderer,
                "§f" + label, sw/2, y+BAR_H+3, 0xFFFFFF);
    }

    private static String formatTime(int s) {
        return s >= 60 ? (s/60) + ":" + String.format("%02d", s%60) : s + "s";
    }
}
