package com.chameleon.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Harita seçim ekranı.
 *
 * ┌─────────────────────────────────────────┐
 * │         🗺 HARİTA SEÇ                   │
 * │                                         │
 * │  [  Harita 1  ] [  Harita 2  ] [  ?  ] │
 * │  [  Harita 4  ] [  Harita 5  ] [  ?  ] │
 * │           [  Harita 7  ]                │
 * │                                         │
 * │                          [  Kapat  ]    │
 * └─────────────────────────────────────────┘
 *
 * Sunucudan OPEN_MAP_SELECT paketi gelince ChameleonClient bu ekranı açar.
 * Haritalar dolunca slot otomatik aktif olur, boş slotlar "Yakında" gösterir.
 */
@Environment(EnvType.CLIENT)
public class MapSelectScreen extends Screen {

    private static final int TOTAL_SLOTS = 7;    // Toplam harita yuvası
    private static final int SLOT_W      = 140;
    private static final int SLOT_H      = 60;
    private static final int COLS        = 3;
    private static final int GAP         = 12;

    private final List<String> mapNames;
    private final List<String> mapDescs;
    private int hoveredSlot = -1;

    public MapSelectScreen(List<String> mapNames, List<String> mapDescs) {
        super(Text.literal("Harita Seç"));
        this.mapNames = mapNames;
        this.mapDescs = mapDescs;
    }

    @Override
    protected void init() {
        int startX = (this.width  - (COLS * SLOT_W + (COLS - 1) * GAP)) / 2;
        int startY = 60;

        for (int i = 0; i < TOTAL_SLOTS; i++) {
            boolean hasMap = i < mapNames.size();
            int col = i % COLS;
            int row = i / COLS;

            // Son satırda tek eleman varsa ortala
            int totalInRow = Math.min(COLS, TOTAL_SLOTS - row * COLS);
            int rowStartX  = (this.width - (totalInRow * SLOT_W + (totalInRow - 1) * GAP)) / 2;

            int bx = rowStartX + col * (SLOT_W + GAP);
            int by = startY + row * (SLOT_H + GAP);

            if (hasMap) {
                final String mapName = mapNames.get(i);
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("§a" + mapName), btn -> voteForMap(mapName))
                        .dimensions(bx, by, SLOT_W, SLOT_H).build());
            } else {
                // Boş slot — devre dışı
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("§7Yakında..."), btn -> {})
                        .dimensions(bx, by, SLOT_W, SLOT_H)
                        .build());
            }
        }

        // Kapat butonu
        addDrawableChild(ButtonWidget.builder(Text.literal("✕ Kapat"), btn -> close())
                .dimensions(this.width - 80, this.height - 30, 70, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Yarı saydam arka plan
        ctx.fill(0, 0, this.width, this.height, 0xAA000000);
        super.render(ctx, mouseX, mouseY, delta);

        // Başlık
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§6§l🗺 HARİTA SEÇ", this.width / 2, 20, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§7Oynamak istediğin haritaya tıkla",
                this.width / 2, 34, 0xAAAAAA);

        // Harita açıklamaları (hover'da göster)
        if (hoveredSlot >= 0 && hoveredSlot < mapDescs.size()) {
            String desc = mapDescs.get(hoveredSlot);
            if (!desc.isEmpty())
                ctx.drawCenteredTextWithShadow(textRenderer,
                        "§7" + desc, this.width / 2, this.height - 50, 0xAAAAAA);
        }

        // Alt bilgi
        if (mapNames.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    "§cHenüz harita eklenmemiş. 7 slotun hepsi yakında doluyor!",
                    this.width / 2, this.height - 20, 0xFF6666);
        } else {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    "§7" + mapNames.size() + "/7 harita mevcut",
                    this.width / 2, this.height - 20, 0x888888);
        }
    }

    @Override
    public void renderBackground(DrawContext ctx) {
        // Oyun arka planı görünsün — dirt ekranını bastır
    }

    private void voteForMap(String mapName) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(mapName);
        ClientPlayNetworking.send(
                new net.minecraft.util.Identifier("chameleon", "map_vote"), buf);
        close();
    }

    @Override
    public boolean shouldPause() { return false; }
}
