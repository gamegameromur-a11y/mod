package com.chameleon.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * İstemci tarafında tutulan oyun durumu.
 * Sunucudan gelen GAME_STATE, GAME_RESULT ve PLAYER_CAUGHT
 * paketleri ile güncellenir.
 */
@Environment(EnvType.CLIENT)
public class GameClientState {

    /** Oyun fazı ID'si (GameState.id ile eşleşir). */
    public static int   stateId      = 0;   // 0 = WAITING
    public static int   timerSeconds = 0;
    public static int   hidersAlive  = 0;
    public static int   totalHiders  = 0;
    public static String winnerText  = "";
    public static long  lastUpdate   = 0;   // System.currentTimeMillis()

    /** Mevcut harita seçim listesi (OPEN_MAP_SELECT ile dolar). */
    public static final java.util.List<String> mapNames = new java.util.ArrayList<>();
    public static final java.util.List<String> mapDescs = new java.util.ArrayList<>();

    /** Son yakalanan oyuncunun adı ve ekranda görünme süresi. */
    public static String caughtPlayerName = "";
    public static long   caughtAt         = 0; // millis

    // ── Yardımcılar ──────────────────────────────────────────────────────────

    public static boolean isGameActive() {
        return stateId >= 2; // COUNTDOWN ve üzeri
    }

    public static boolean isHidingPhase() { return stateId == 3; }
    public static boolean isSeekingPhase(){ return stateId == 4; }
    public static boolean isEnded()       { return stateId == 5; }
    public static boolean isWaiting()     { return stateId <= 1; }
}
