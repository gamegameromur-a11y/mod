package com.chameleon.client;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Boyama HUD Paneli — PaintScreen'in yerini alır.
 *
 * Kullanım:
 *   C tuşu basılı → ekranın SAĞ tarafında panel açılır, fare serbest
 *   C tuşu bırakılır → panel kapanır, kamera kontrolü geri döner
 *
 * Sol tarafta oyun dünyası görünür, sol alana tıklandığında
 * 3D raycast ile kendi karakterine çarpılıyorsa boya uygulanır (UUID kontrolü).
 *
 * Panel genişliği: PANEL_W = 210 px, sağa sabit.
 */
@Environment(EnvType.CLIENT)
public class PaintHudScreen extends Screen {

    // ── Sabitler ──────────────────────────────────────────────────────────────
    /** Sağdaki panel genişliği (piksel). */
    private static final int PANEL_W = 210;
    /** Hücre başına piksel — renk paleti ızgarası. */
    private static final int SWATCH = 16;
    /** Sekme butonu yüksekliği. */
    private static final int TAB_H  = 14;

    // ── Durum ─────────────────────────────────────────────────────────────────
    private PaintData paintData;
    private int   currentColor   = 0xFF4CAF50; // varsayılan yeşil
    private int   brushRadius    = 3;
    private boolean eyedropperMode = false;
    private boolean isDragging     = false;

    // HSV özel picker
    private float hue = 0.33f, sat = 1f, val = 1f, alpha = 1f;
    private boolean draggingHue = false, draggingSV = false;

    // ── Palet sekmeleri ───────────────────────────────────────────────────────
    private enum Tab { MECCHA, BASIC, NATURE, SKIN, PASTEL, NEON, DARK, EARTH, HSV }
    private Tab activeTab = Tab.MECCHA;

    // ── Renk tabloları ────────────────────────────────────────────────────────
    private static final int[] MECCHA = {
        0xFFFFFFFF,0xFFE8E8E8,0xFFCCCCCC,0xFFAAAAAA,0xFF888888,0xFF555555,0xFF333333,0xFF000000,
        0xFFFFB3B3,0xFFFF8080,0xFFFF4C4C,0xFFFF0000,0xFFCC0000,0xFF990000,0xFF660000,0xFF3D0000,
        0xFFFFCE9E,0xFFFFAE60,0xFFFF8C00,0xFFFF6B00,0xFFE05200,0xFFB84000,0xFF7A2A00,0xFF4A1500,
        0xFFFFF59D,0xFFFFEE58,0xFFFFD600,0xFFFFBF00,0xFFFF8F00,0xFFE65100,0xFF8D6E63,0xFF5D4037,
        0xFFF0F4C3,0xFFE6EE9C,0xFFD4E157,0xFFCDDC39,0xFFAFB42B,0xFF827717,0xFF558B2F,0xFF1B5E20,
        0xFFA5D6A7,0xFF66BB6A,0xFF4CAF50,0xFF388E3C,0xFF2E7D32,0xFF00C853,0xFF00BFA5,0xFF004D40,
        0xFF80DEEA,0xFF26C6DA,0xFF00BCD4,0xFF00838F,0xFF006064,0xFF0097A7,0xFF00B0FF,0xFF01579B,
        0xFF90CAF9,0xFF42A5F5,0xFF2196F3,0xFF1565C0,0xFF0D47A1,0xFF7E57C2,0xFF673AB7,0xFF1A0050,
        0xFFB39DDB,0xFF9575CD,0xFF7E57C2,0xFF512DA8,0xFF311B92,0xFFCE93D8,0xFFAB47BC,0xFF880E4F,
        0xFFF48FB1,0xFFF06292,0xFFE91E63,0xFFC2185B,0xFF880E4F,0xFFD4C5A9,0xFFB07850,0xFF6D4C41,
    };
    private static final int[] BASIC = {
        0xFFFFFFFF,0xFF000000,0xFFFF0000,0xFF00FF00,0xFF0000FF,0xFFFFFF00,0xFFFF00FF,0xFF00FFFF,
        0xFFFF8000,0xFF8000FF,0xFF008000,0xFF800000,0xFF000080,0xFF808000,0xFF008080,0xFF800080,
        0xFFC0C0C0,0xFF808080,0xFF404040,0xFFFFFFAA,0xFF00FF80,0xFF8000FF,0xFFFF0080,0xFF80FF00,
    };
    private static final int[] NATURE = {
        0xFF2D5A1B,0xFF3D7A26,0xFF4E9E32,0xFF5CB83A,0xFF8BC34A,0xFFA5D65A,0xFFB8E06A,0xFFD4F0A0,
        0xFF3B2507,0xFF5C3A0F,0xFF7A4F1A,0xFF9A6628,0xFFB8833C,0xFFD4A054,0xFFE8C07A,0xFFF5DCA0,
        0xFF87CEEB,0xFF6BB8DC,0xFF4FA2CC,0xFF3388BB,0xFF1A6FA8,0xFF0D5490,0xFF053878,0xFF021F50,
        0xFF00CED1,0xFF009FB5,0xFF007A8C,0xFF005668,0xFF003344,0xFF00897B,0xFF00ACC1,0xFF0288D1,
        0xFFFF69B4,0xFFFF1493,0xFFDB1C8E,0xFFB5006C,0xFF8B0057,0xFFFF6B35,0xFFFF8C42,0xFFFFCB47,
    };
    private static final int[] SKIN = {
        0xFFFFDFC4,0xFFF0C8A0,0xFFDEB887,0xFFD2996A,0xFFC68642,0xFFB5722A,0xFFA0522D,0xFF8B4513,
        0xFF7B3F00,0xFF6B3322,0xFF5C2D0E,0xFF4A1F0A,0xFFFFC8A0,0xFFFFB489,0xFFFF9A70,0xFFEE8260,
        0xFFFFE0A0,0xFFEFD090,0xFFDFB870,0xFFCF9850,0xFFCD7F5A,0xFFB5603A,0xFF9A4020,0xFF7A2810,
        0xFFF5CBA7,0xFFE8B896,0xFFD4956A,0xFFC07840,0xFFA05C28,0xFF804018,0xFF60300C,0xFF402008,
    };
    private static final int[] PASTEL = {
        0xFFFFB3BA,0xFFFFCCBA,0xFFFFFFBA,0xFFBAFFBA,0xFFBAF3FF,0xFFBAC8FF,0xFFE8BAFF,0xFFFFBAF0,
        0xFFFFD9B3,0xFFD9FFB3,0xFFB3FFD9,0xFFB3EEFF,0xFFB3C6FF,0xFFD4B3FF,0xFFFFB3DA,0xFFFFF0F5,
        0xFFF0FFF0,0xFFF0F8FF,0xFFFFFAF0,0xFFF5F0FF,0xFFFFE4E1,0xFFE6E6FA,0xFFF0E6FF,0xFFE1F5FE,
        0xFFE8F5E9,0xFFFFF9C4,0xFFFFCCBC,0xFFD7CCC8,0xFFCFD8DC,0xFFB2DFDB,0xFFDCEDC8,0xFFE1BEE7,
    };
    private static final int[] NEON = {
        0xFFFF0080,0xFFFF0040,0xFFFF4000,0xFFFF8000,0xFFFFBF00,0xFFFFFF00,0xFFBFFF00,0xFF80FF00,
        0xFF40FF00,0xFF00FF00,0xFF00FF40,0xFF00FF80,0xFF00FFBF,0xFF00FFFF,0xFF00BFFF,0xFF0080FF,
        0xFF0040FF,0xFF0000FF,0xFF4000FF,0xFF8000FF,0xFFBF00FF,0xFFFF00FF,0xFFFF00BF,0xFFFF3333,
        0xFF33FF33,0xFF3333FF,0xFFFF33FF,0xFF33FFFF,0xFFFFFF33,0xFFFF6600,0xFF00FF66,0xFF6600FF,
    };
    private static final int[] DARK = {
        0xFF1A0A0A,0xFF2D0A0A,0xFF1A1A0A,0xFF0A1A0A,0xFF0A1A1A,0xFF0A0A1A,0xFF1A0A1A,0xFF1A1A1A,
        0xFF3D0000,0xFF003D00,0xFF00003D,0xFF3D003D,0xFF003D3D,0xFF3D3D00,0xFF4A1010,0xFF10104A,
        0xFF1F3A1F,0xFF1F1F3A,0xFF3A1F1F,0xFF3A3A1F,0xFF1F3A3A,0xFF0D0D0D,0xFF111111,0xFF222222,
        0xFF280000,0xFF002800,0xFF000028,0xFF280028,0xFF002828,0xFF282800,0xFF050505,0xFF181818,
    };
    private static final int[] EARTH = {
        0xFFF5DEB3,0xFFEDD9A3,0xFFE4C87A,0xFFD2B055,0xFFBE9A3A,0xFFB5651D,0xFFA0522D,0xFF8B4513,
        0xFF9E9E9E,0xFF8E8E8E,0xFF757575,0xFF616161,0xFF424242,0xFF795548,0xFF6D4C41,0xFF3E2723,
        0xFFECEFF1,0xFFCFD8DC,0xFFB0BEC5,0xFF90A4AE,0xFF78909C,0xFF607D8B,0xFF455A64,0xFF263238,
        0xFF33691E,0xFF558B2F,0xFF7CB342,0xFF8BC34A,0xFF4A1500,0xFFBF360C,0xFFE64A19,0xFF80DEEA,
    };

    public PaintHudScreen() {
        super(Text.translatable("screen.chameleon.paint"));
    }

    @Override
    protected void init() {
        int px = panelX();
        int y  = 8;

        // Sekme butonları — 3 sütun, 3 satır
        Tab[] tabs = Tab.values();
        int tw = 64, th = TAB_H, gap = 2;
        for (int i = 0; i < tabs.length; i++) {
            final Tab tab = tabs[i];
            int bx = px + (i % 3) * (tw + gap);
            int by = y  + (i / 3) * (th + gap);
            addDrawableChild(ButtonWidget.builder(Text.literal(tabLabel(tab)), btn -> activeTab = tab)
                    .dimensions(bx, by, tw, th).build());
        }

        int bottomY = this.height - 52;

        // Fırça boyutu
        addDrawableChild(ButtonWidget.builder(Text.literal("−"), btn -> {
            if (brushRadius > 1) brushRadius--;
        }).dimensions(px, bottomY, 24, 14).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("+"), btn -> {
            if (brushRadius < 12) brushRadius++;
        }).dimensions(px + 28, bottomY, 24, 14).build());

        // Damlalık
        addDrawableChild(ButtonWidget.builder(Text.literal("💧"), btn -> eyedropperMode = !eyedropperMode)
                .dimensions(px + 56, bottomY, 24, 14).build());

        // Sıfırla
        addDrawableChild(ButtonWidget.builder(Text.literal("↺ Sıfırla"), btn -> {
            getPaintData().reset();
            sendStroke(PaintData.GRID_W / 2, PaintData.GRID_H / 2, 999, 0xFFFFFFFF);
        }).dimensions(px + 84, bottomY, 60, 14).build());

        // Kapat
        addDrawableChild(ButtonWidget.builder(Text.literal("✕"), btn -> close())
                .dimensions(px + 148, bottomY, 24, 14).build());
    }

    // ── Render ────────────────────────────────────────────────────────────────

    @Override
    public void renderBackground(DrawContext ctx) {
        // Oyun dünyası arka planda görünsün — karartma yok
        // Sadece panel arka planını çiz
        ctx.fill(panelX() - 4, 0, this.width, this.height, 0xCC000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        super.render(ctx, mouseX, mouseY, delta); // widget'lar

        int px = panelX();
        int y  = 8;

        // ── Sekme highlight (aktif sekme) ────────────────────────────────────
        Tab[] tabs = Tab.values();
        int tw = 64, th = TAB_H, gap = 2;
        for (int i = 0; i < tabs.length; i++) {
            if (tabs[i] == activeTab) {
                int bx = px + (i % 3) * (tw + gap);
                int by = y  + (i / 3) * (th + gap);
                // Altın sarısı çerçeve = aktif sekme vurgusu (düzeltme #9)
                ctx.drawBorder(bx - 1, by - 1, tw + 2, th + 2, 0xFFFFD700);
            }
        }

        // ── Palet ─────────────────────────────────────────────────────────
        int paletteY = y + 3 * (TAB_H + gap) + 4;
        if (activeTab == Tab.HSV) {
            renderHsvPicker(ctx, px, paletteY, mouseX, mouseY);
        } else {
            renderColorGrid(ctx, px, paletteY, activeColors(), mouseX, mouseY);
        }

        // ── Bilgi alanı ───────────────────────────────────────────────────
        int infoY = this.height - 90;
        ctx.drawText(textRenderer, "Seçili renk:", px, infoY, 0xCCCCCC, false);
        ctx.fill(px, infoY + 10, px + PANEL_W - 8, infoY + 26, currentColor);
        ctx.drawBorder(px - 1, infoY + 9, PANEL_W - 6, 18, 0xFFFFFFFF);
        ctx.drawText(textRenderer,
                String.format("#%06X  A:%d%%", currentColor & 0xFFFFFF,
                        (int)(((currentColor >> 24) & 0xFF) / 2.55f)),
                px, infoY + 30, 0xCCCCCC, false);

        // ── Fırça bilgisi ─────────────────────────────────────────────────
        int bottomY = this.height - 52;
        ctx.drawText(textRenderer,
                "Fırça: " + brushRadius + (eyedropperMode ? "  §eDAMLALIK" : ""),
                px, bottomY - 12, eyedropperMode ? 0xFFFF44 : 0xCCCCCC, false);

        // 3D boyama ipucu
        ctx.drawText(textRenderer, "§7Sol taraf: 3D boyama", px, this.height - 16, 0xAAAAAA, false);
    }

    private void renderColorGrid(DrawContext ctx, int x, int y, int[] colors, int mx, int my) {
        int cols = 8;
        for (int i = 0; i < colors.length; i++) {
            int px = x  + (i % cols) * SWATCH;
            int py = y  + (i / cols) * SWATCH;
            ctx.fill(px, py, px + SWATCH - 2, py + SWATCH - 2, colors[i]);
            if (colors[i] == currentColor)
                ctx.drawBorder(px - 1, py - 1, SWATCH, SWATCH, 0xFFFFD700);
            if (mx >= px && mx < px + SWATCH - 2 && my >= py && my < py + SWATCH - 2)
                ctx.drawBorder(px - 1, py - 1, SWATCH, SWATCH, 0xFFFFFFFF);
        }
    }

    private void renderHsvPicker(DrawContext ctx, int x, int y, int mx, int my) {
        int sq = 100;
        // S-V karesi
        for (int sy = 0; sy < sq; sy++)
            for (int sx = 0; sx < sq; sx++)
                ctx.fill(x + sx, y + sy, x + sx + 1, y + sy + 1,
                        hsvToArgb(hue, sx / (float)sq, 1f - sy / (float)sq));
        ctx.drawBorder(x - 1, y - 1, sq + 2, sq + 2, 0xFFFFFFFF);
        int svX = x + (int)(sat * sq), svY = y + (int)((1f - val) * sq);
        ctx.fill(svX - 3, svY - 3, svX + 3, svY + 3, 0xFFFFFFFF);
        ctx.fill(svX - 2, svY - 2, svX + 2, svY + 2, 0xFF000000);

        // Ton (Hue) çubuğu
        int hx = x + sq + 6;
        for (int hy = 0; hy < sq; hy++)
            ctx.fill(hx, y + hy, hx + 14, y + hy + 1, hsvToArgb(hy / (float)sq, 1f, 1f));
        ctx.drawBorder(hx - 1, y - 1, 16, sq + 2, 0xFFFFFFFF);
        int hueBarY = y + (int)(hue * sq);
        ctx.fill(hx - 3, hueBarY - 1, hx + 17, hueBarY + 2, 0xFFFFFFFF);

        // Alfa çubuğu
        int ax = hx + 18;
        for (int ay = 0; ay < sq; ay++) {
            int gray = (int)((1f - ay / (float)sq) * 255);
            ctx.fill(ax, y + ay, ax + 14, y + ay + 1,
                    (gray << 24) | (currentColor & 0x00FFFFFF) | 0xFF000000);
        }
        ctx.drawBorder(ax - 1, y - 1, 16, sq + 2, 0xFFAAAAAA);
        int alphaBarY = y + (int)((1f - alpha) * sq);
        ctx.fill(ax - 3, alphaBarY - 1, ax + 17, alphaBarY + 2, 0xFFFFFFFF);

        ctx.drawText(textRenderer, "S/V", x + 38, y + sq + 3, 0xAAAAAA, false);
        ctx.drawText(textRenderer, "H", hx + 3, y + sq + 3, 0xAAAAAA, false);
        ctx.drawText(textRenderer, "A", ax + 3, y + sq + 3, 0xAAAAAA, false);
    }

    // ── Mouse ─────────────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (mx < panelX()) {
            // Sol alan → 3D raycast boya (UUID kontrolü)
            doWorldPaint();
            return true;
        }
        if (handlePaletteClick(mx, my)) return true;
        if (handleHsvClick(mx, my))     return true;
        isDragging = true;
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (draggingHue || draggingSV) { handleHsvDrag(mx, my); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        isDragging = false; draggingHue = false; draggingSV = false;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        if (mx >= panelX()) {
            brushRadius = Math.max(1, Math.min(12, brushRadius + (int)Math.signum(amount)));
            return true;
        }
        return super.mouseScrolled(mx, my, amount);
    }

    // ── 3D Dünya Boyama (UUID kontrolü) ──────────────────────────────────────

    /**
     * Kameradan raycast atar; yalnızca KENDİ UUID'li karaktere çarparsa boya uygular.
     * Başka bir oyuncuya çarpıyorsa hiçbir şey yapmaz.
     */
    private void doWorldPaint() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        double range = 4.5;
        Vec3d start  = mc.player.getCameraPosVec(1.0f);
        Vec3d dir    = mc.player.getRotationVec(1.0f);
        Vec3d end    = start.add(dir.multiply(range));
        Box   box    = mc.player.getBoundingBox().stretch(dir.multiply(range)).expand(1.0);

        // Raycast — tüm oyuncu varlıklarını kontrol et
        EntityHitResult hit = ProjectileUtil.getEntityCollision(
                mc.world, mc.player, start, end, box,
                e -> e instanceof PlayerEntity && !e.isSpectator());

        if (hit == null) return;
        Entity target = hit.getEntity();

        // ── UUID kontrolü: yalnızca kendisi ──
        if (!target.getUuid().equals(mc.player.getUuid())) return;

        // 3D çarpma noktasını 2D grid'e çevir
        Vec3d hitPos = hit.getPos();
        float relY   = (float)((hitPos.y - target.getY()) / target.getHeight());
        int gridY    = Math.max(0, Math.min(PaintData.GRID_H - 1,
                PaintData.GRID_H - 1 - (int)(relY * PaintData.GRID_H)));

        double dx  = hitPos.x - target.getX();
        double dz  = hitPos.z - target.getZ();
        double yaw = Math.toRadians(target.getYaw());
        double localX = -dx * Math.cos(yaw) - dz * Math.sin(yaw);
        int gridX = Math.max(0, Math.min(PaintData.GRID_W - 1,
                (int)(((localX + 0.3) / 0.6) * PaintData.GRID_W)));

        getPaintData().paintBrush(gridX, gridY, brushRadius, currentColor);
        sendStroke(gridX, gridY, brushRadius, currentColor);
    }

    // ── Palet tıklama yardımcıları ────────────────────────────────────────────

    private boolean handlePaletteClick(double mx, double my) {
        if (activeTab == Tab.HSV) return false;
        int px = panelX(), py = 8 + 3 * (TAB_H + 2) + 4;
        int[] colors = activeColors();
        for (int i = 0; i < colors.length; i++) {
            int cx = px + (i % 8) * SWATCH;
            int cy = py + (i / 8) * SWATCH;
            if (mx >= cx && mx < cx + SWATCH - 2 && my >= cy && my < cy + SWATCH - 2) {
                currentColor  = colors[i];
                eyedropperMode = false;
                return true;
            }
        }
        return false;
    }

    private boolean handleHsvClick(double mx, double my) {
        if (activeTab != Tab.HSV) return false;
        int px = panelX(), py = 8 + 3 * (TAB_H + 2) + 4, sq = 100;
        int hx = px + sq + 6, ax = hx + 18;
        if (mx >= px && mx < px + sq && my >= py && my < py + sq) {
            draggingSV = true; sat = (float)((mx - px) / sq); val = 1f - (float)((my - py) / sq);
            updateHsvColor(); return true;
        }
        if (mx >= hx && mx < hx + 14 && my >= py && my < py + sq) {
            draggingHue = true; hue = (float)((my - py) / sq);
            updateHsvColor(); return true;
        }
        if (mx >= ax && mx < ax + 14 && my >= py && my < py + sq) {
            alpha = 1f - (float)((my - py) / sq); updateHsvColor(); return true;
        }
        return false;
    }

    private void handleHsvDrag(double mx, double my) {
        int px = panelX(), py = 8 + 3 * (TAB_H + 2) + 4, sq = 100;
        int ax = px + sq + 6 + 18;
        if (draggingSV)   { sat = c01((float)((mx - px) / sq)); val = c01(1f - (float)((my - py) / sq)); }
        else if (draggingHue) { hue = c01((float)((my - py) / sq)); }
        else if (mx >= ax && mx < ax + 14) { alpha = c01(1f - (float)((my - py) / sq)); }
        updateHsvColor();
    }

    private void updateHsvColor() {
        currentColor = hsvToArgb(hue, sat, val);
        int a = (int)(alpha * 255) & 0xFF;
        currentColor = (currentColor & 0x00FFFFFF) | (a << 24);
    }

    // ── Yardımcılar ───────────────────────────────────────────────────────────

    /** Panel sol kenar X koordinatı — ekranın sağına sabit. */
    private int panelX() { return this.width - PANEL_W; }

    private PaintData getPaintData() {
        if (paintData == null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) paintData = PlayerPaintStore.getPaint(mc.player);
        }
        return paintData;
    }

    private void sendStroke(int cx, int cy, int radius, int color) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(cx); buf.writeInt(cy); buf.writeInt(radius); buf.writeInt(color);
        ClientPlayNetworking.send(ChameleonNetwork.PAINT_STROKE, buf);
    }

    private String tabLabel(Tab t) {
        return switch (t) {
            case MECCHA -> "MECCHA"; case BASIC -> "Temel";  case NATURE -> "Doğa";
            case SKIN   -> "Ten";   case PASTEL -> "Pastel"; case NEON   -> "Neon";
            case DARK   -> "Koyu";  case EARTH  -> "Toprak"; case HSV    -> "HSV";
        };
    }

    private int[] activeColors() {
        return switch (activeTab) {
            case MECCHA -> MECCHA; case BASIC -> BASIC; case NATURE -> NATURE;
            case SKIN   -> SKIN;  case PASTEL -> PASTEL; case NEON  -> NEON;
            case DARK   -> DARK;  case EARTH  -> EARTH;
            default     -> new int[0];
        };
    }

    private static int hsvToArgb(float h, float s, float v) {
        float r, g, b;
        if (s == 0f) { r = g = b = v; }
        else {
            float sec = h * 6f; int i = (int)sec; float f = sec - i;
            float p = v*(1f-s), q = v*(1f-s*f), t = v*(1f-s*(1f-f));
            switch (i % 6) {
                case 0 -> { r=v; g=t; b=p; } case 1 -> { r=q; g=v; b=p; }
                case 2 -> { r=p; g=v; b=t; } case 3 -> { r=p; g=q; b=v; }
                case 4 -> { r=t; g=p; b=v; } default -> { r=v; g=p; b=q; }
            }
        }
        return 0xFF000000 | ((int)(r*255) << 16) | ((int)(g*255) << 8) | (int)(b*255);
    }

    private static float c01(float v) { return Math.max(0f, Math.min(1f, v)); }

    @Override public boolean shouldPause()    { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }
}
