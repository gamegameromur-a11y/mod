package com.chameleon.client;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

/**
 * FIX 3 & 5: Boyama ekranı — tam yeniden yazım.
 *
 *  TOGGLE: C'ye bir kez bas = aç, bir kez daha = kapat (artık basılı tutmaya gerek yok)
 *
 *  PANEL DÜZENİ:
 *   Sol %55 : 2D karakter önizlemesi — body bölgelerine tıklayarak boya
 *   Sağ %45 : Renk paleti (sekmeli) + fırça boyutu
 *
 *  BOYAMA ÇALIŞMASI:
 *   1. Sağ panelde renk seç
 *   2. Sol panelde karakter bölgesine (baş/gövde/kol/bacak) tıkla
 *   3. O bölge seçili renge boyanır ve PAINT_STROKE paketi sunucuya gönderilir
 *   4. Tüm istemciler anlık olarak güncellenir
 */
@Environment(EnvType.CLIENT)
public class PaintHudScreen extends Screen {

    // ── Panel boyutları ─────────────────────────────────────────────────────
    private static final int SWATCH = 14;   // renk kutucuğu px
    private static final int COLS   = 8;    // palet sütun sayısı
    private static final int TAB_H  = 12;   // sekme yüksekliği

    // ── Karakter önizleme ölçüleri ─────────────────────────────────────────
    private static final int CHAR_SCALE = 5; // her UV birimi = 5 ekran pikseli
    // Steve oranları: baş 8×8, gövde 8×12, kol 4×12, bacak 4×12
    private static final int HEAD_W  = 8  * CHAR_SCALE;
    private static final int HEAD_H  = 8  * CHAR_SCALE;
    private static final int BODY_W  = 8  * CHAR_SCALE;
    private static final int BODY_H  = 12 * CHAR_SCALE;
    private static final int ARM_W   = 4  * CHAR_SCALE;
    private static final int ARM_H   = 12 * CHAR_SCALE;
    private static final int LEG_W   = 4  * CHAR_SCALE;
    private static final int LEG_H   = 12 * CHAR_SCALE;

    // ── Durum ───────────────────────────────────────────────────────────────
    private int   currentColor = 0xFF4CAF50;
    private int   brushRadius  = 3;
    private Tab   activeTab    = Tab.MECCHA;
    private PaintData localData;
    /** HATA #6: Paket taşması önleme — 50ms altında tekrar gönderim yapılmaz. */
    private long lastPaintMs = 0;

    private enum Tab { MECCHA, TEMEL, DOGA, TEN, PASTEL, NEON, KOYU, TOPRAK }

    // ── Renkler ─────────────────────────────────────────────────────────────
    private static final int[] MECCHA = {
        0xFFFFFFFF,0xFFE0E0E0,0xFFBDBDBD,0xFF9E9E9E,0xFF757575,0xFF616161,0xFF424242,0xFF212121,
        0xFFFFCDD2,0xFFEF9A9A,0xFFE57373,0xFFEF5350,0xFFE53935,0xFFC62828,0xFF9C1010,0xFF6D0000,
        0xFFFFE0B2,0xFFFFCC80,0xFFFFB74D,0xFFFFA726,0xFFFF9800,0xFFFB8C00,0xFFE65100,0xFFBF360C,
        0xFFFFF9C4,0xFFFFF176,0xFFFFEE58,0xFFFFEB3B,0xFFFFD600,0xFFFFC107,0xFFFF8F00,0xFFFF6F00,
        0xFFF1F8E9,0xFFDCEDC8,0xFFC5E1A5,0xFFA5D6A7,0xFF81C784,0xFF66BB6A,0xFF4CAF50,0xFF388E3C,
        0xFFE0F7FA,0xFFB2EBF2,0xFF80DEEA,0xFF4DD0E1,0xFF26C6DA,0xFF00BCD4,0xFF0097A7,0xFF006064,
        0xFFE3F2FD,0xFFBBDEFB,0xFF90CAF9,0xFF64B5F6,0xFF42A5F5,0xFF2196F3,0xFF1565C0,0xFF0D47A1,
        0xFFEDE7F6,0xFFD1C4E9,0xFFB39DDB,0xFF9575CD,0xFF7E57C2,0xFF673AB7,0xFF4527A0,0xFF311B92,
        0xFFFCE4EC,0xFFF8BBD9,0xFFF48FB1,0xFFF06292,0xFFEC407A,0xFFE91E63,0xFFC2185B,0xFF880E4F,
        0xFFFFF8E1,0xFFFFECB3,0xFFFFE082,0xFFFFD54F,0xFFFFCA28,0xFFFFB300,0xFFFF8F00,0xFFFF6F00,
    };
    private static final int[] TEMEL = {
        0xFFFFFFFF,0xFF000000,0xFFFF0000,0xFF00FF00,0xFF0000FF,0xFFFFFF00,0xFFFF00FF,0xFF00FFFF,
        0xFFFF8000,0xFF8000FF,0xFF008040,0xFF800040,0xFF000080,0xFF808000,0xFF008080,0xFF800080,
    };
    private static final int[] DOGA = {
        0xFF2E7D32,0xFF388E3C,0xFF43A047,0xFF4CAF50,0xFF66BB6A,0xFF81C784,0xFFA5D6A7,0xFFC8E6C9,
        0xFF1565C0,0xFF1976D2,0xFF1E88E5,0xFF42A5F5,0xFF64B5F6,0xFF90CAF9,0xFFBBDEFB,0xFFE3F2FD,
        0xFF4E342E,0xFF5D4037,0xFF6D4C41,0xFF795548,0xFF8D6E63,0xFFA1887F,0xFFBCAAA4,0xFFD7CCC8,
    };
    private static final int[] TEN = {
        0xFFFFE0BD,0xFFFFD5B0,0xFFF5C09A,0xFFE8AD87,0xFFD4956A,0xFFC07840,0xFFA05C28,0xFF7A4018,
        0xFF6D3522,0xFF5C2D18,0xFF4A2010,0xFF3D1808,0xFFFFC8A0,0xFFFFB080,0xFFFF9868,0xFFEE8050,
    };
    private static final int[] PASTEL = {
        0xFFFFB3BA,0xFFFFCCBA,0xFFFFFFBA,0xFFBAFFBA,0xFFBAEFFF,0xFFBAC8FF,0xFFE0BAFF,0xFFFFBAEA,
        0xFFFFD9B3,0xFFD9FFB3,0xFFB3FFD9,0xFFB3EEFF,0xFFB3C8FF,0xFFD4B3FF,0xFFFFB3D4,0xFFFFF5F5,
    };
    private static final int[] NEON = {
        0xFFFF0080,0xFFFF0040,0xFFFF4000,0xFFFF8000,0xFFFFBF00,0xFFFFFF00,0xFFBFFF00,0xFF80FF00,
        0xFF00FF00,0xFF00FF80,0xFF00FFFF,0xFF00BFFF,0xFF0080FF,0xFF0040FF,0xFF8000FF,0xFFFF00FF,
    };
    private static final int[] KOYU = {
        0xFF1A0A0A,0xFF2D0000,0xFF001A00,0xFF00001A,0xFF1A001A,0xFF001A1A,0xFF1A1A00,0xFF0D0D0D,
        0xFF3D0000,0xFF003D00,0xFF00003D,0xFF3D003D,0xFF003D3D,0xFF3D3D00,0xFF222222,0xFF111111,
    };
    private static final int[] TOPRAK = {
        0xFFF5DEB3,0xFFEDD9A3,0xFFE4C87A,0xFFD2B055,0xFFBE9A3A,0xFFB5651D,0xFFA0522D,0xFF8B4513,
        0xFF9E9E9E,0xFF757575,0xFF616161,0xFF424242,0xFF795548,0xFF6D4C41,0xFF5D4037,0xFF4E342E,
    };

    public PaintHudScreen() {
        super(Text.literal("Boyama"));
    }

    @Override
    protected void init() {
        // Sekme butonları — sağ panelin üstünde 2×4 düzende
        int px = panelX();
        Tab[] tabs = Tab.values();
        int tw = (PANEL_W() - 4) / 4, th = TAB_H;
        for (int i = 0; i < tabs.length; i++) {
            final Tab t = tabs[i];
            int bx = px + 2 + (i % 4) * tw;
            int by = 6  + (i / 4) * (th + 2);
            addDrawableChild(ButtonWidget.builder(Text.literal(tabShort(t)), btn -> {
                activeTab = t;
            }).dimensions(bx, by, tw - 1, th).build());
        }

        // Fırça − ve + butonları
        int toolY = this.height - 38;
        addDrawableChild(ButtonWidget.builder(Text.literal("−"), b -> {
            if (brushRadius > 1) brushRadius--;
        }).dimensions(px + 2, toolY, 22, 14).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            if (brushRadius < 8) brushRadius++;
        }).dimensions(px + 26, toolY, 22, 14).build());

        // Sıfırla
        addDrawableChild(ButtonWidget.builder(Text.literal("↺ Sıfırla"), b -> {
            getLocalData().reset();
            sendFill(PaintData.GRID_W / 2, PaintData.GRID_H / 2, 64, 0xFFFFFFFF);
        }).dimensions(px + 52, toolY, 60, 14).build());

        // Kapat
        addDrawableChild(ButtonWidget.builder(Text.literal("✕"), b -> close())
            .dimensions(px + PANEL_W() - 22, toolY, 20, 14).build());
    }

    // ── Render ─────────────────────────────────────────────────────────────

    @Override
    public void renderBackground(DrawContext ctx) {
        // Oyun arka planı görünsün; sadece paneli karart
        ctx.fill(panelX() - 2, 0, this.width, this.height, 0xCC101010);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        super.render(ctx, mouseX, mouseY, delta);

        int px = panelX();

        // ── Aktif sekme vurgusu ──────────────────────────────────────────
        Tab[] tabs = Tab.values();
        int tw = (PANEL_W() - 4) / 4, th = TAB_H;
        for (int i = 0; i < tabs.length; i++) {
            if (tabs[i] == activeTab) {
                int bx = px + 2 + (i % 4) * tw;
                int by = 6  + (i / 4) * (th + 2);
                ctx.drawBorder(bx - 1, by - 1, tw, th + 2, 0xFFFFD700); // altın vurgu
            }
        }

        // ── Renk paleti ─────────────────────────────────────────────────
        int paletteY = 6 + 2 * (TAB_H + 2) + 6;
        int[] colors = activeColors();
        for (int i = 0; i < colors.length; i++) {
            int cx2 = px + 2 + (i % COLS) * SWATCH;
            int cy2 = paletteY + (i / COLS) * SWATCH;
            ctx.fill(cx2, cy2, cx2 + SWATCH - 1, cy2 + SWATCH - 1, colors[i]);
            if (colors[i] == currentColor)
                ctx.drawBorder(cx2 - 1, cy2 - 1, SWATCH + 1, SWATCH + 1, 0xFFFFD700);
            if (mouseX >= cx2 && mouseX < cx2 + SWATCH - 1 && mouseY >= cy2 && mouseY < cy2 + SWATCH - 1)
                ctx.drawBorder(cx2 - 1, cy2 - 1, SWATCH + 1, SWATCH + 1, 0xFFFFFFFF);
        }

        // ── Seçili renk & fırça bilgisi ─────────────────────────────────
        int infoY = this.height - 58;
        ctx.drawText(textRenderer, "Renk / Fırça: " + brushRadius, px + 2, infoY, 0xAAAAAA, false);
        ctx.fill(px + 2, infoY + 10, px + PANEL_W() - 2, infoY + 24, currentColor);
        ctx.drawBorder(px + 1, infoY + 9, PANEL_W() - 2, 16, 0x88FFFFFF);
        ctx.drawText(textRenderer,
            String.format("#%06X", currentColor & 0xFFFFFF),
            px + 2, infoY + 26, 0x888888, false);

        // ── Sol panel: 2D karakter önizleme ─────────────────────────────
        renderCharacterPreview(ctx, mouseX, mouseY);

        // ── İpucu ───────────────────────────────────────────────────────
        ctx.drawCenteredTextWithShadow(textRenderer,
            "§7Sol: Karakter bölgesine tıkla → Boya", this.width / 2, this.height - 14, 0x888888);
    }

    /** 2D karakter önizlemesi (sol taraf) — tıklanabilir bölgeler */
    private void renderCharacterPreview(DrawContext ctx, int mx, int my) {
        int cx = (panelX() - 10) / 2; // sol alanın merkezi
        int cy = this.height / 2 - 20;

        // Her bölgenin ekran koordinatları
        int headX = cx - HEAD_W / 2, headY = cy - HEAD_H - BODY_H / 2;
        int bodyX = cx - BODY_W / 2, bodyY = cy - BODY_H / 2;
        int rArmX = bodyX - ARM_W - 2, rArmY = bodyY;
        int lArmX = bodyX + BODY_W + 2, lArmY = bodyY;
        int rLegX = cx - BODY_W / 2, rLegY = bodyY + BODY_H + 1;
        int lLegX = cx, lLegY = bodyY + BODY_H + 1;

        // Her bölgeyi mevcut boya rengiyle çiz (gerçek skin renkleri yok — sadece boyalı preview)
        drawBodyPart(ctx, "BAŞ",   headX, headY, HEAD_W, HEAD_H, mx, my, 12, 4,  4, "head");
        drawBodyPart(ctx, "GÖVDE", bodyX, bodyY, BODY_W, BODY_H, mx, my, 12, 10, 4, "body");
        drawBodyPart(ctx, "SAĞ KOL", rArmX, rArmY, ARM_W, ARM_H, mx, my, 10, 16, 2, "rarm");
        drawBodyPart(ctx, "SOL KOL", lArmX, lArmY, ARM_W, ARM_H, mx, my, 18, 16, 2, "larm");
        drawBodyPart(ctx, "SAĞ BACAK", rLegX, rLegY, LEG_W, LEG_H, mx, my, 10, 28, 2, "rleg");
        drawBodyPart(ctx, "SOL BACAK", lLegX, lLegY, LEG_W, LEG_H, mx, my, 14, 28, 2, "lleg");
    }

    private void drawBodyPart(DrawContext ctx, String label,
                               int bx, int by, int bw, int bh,
                               int mx, int my, int gridCX, int gridCY, int radius,
                               String partId) {
        boolean hovered = mx >= bx && mx < bx + bw && my >= by && my < by + bh;

        // Mevcut boya rengini göster (gerçek texture değil, renk önizlemesi)
        PaintData data = getLocalData();
        int cellColor = data.getCell(gridCX, gridCY);
        ctx.fill(bx, by, bx + bw, by + bh, cellColor);

        // Kenarlık
        ctx.drawBorder(bx - 1, by - 1, bw + 2, bh + 2,
            hovered ? 0xFFFFD700 : 0x88FFFFFF);

        // Etiket
        if (bw > 15) {
            ctx.drawCenteredTextWithShadow(textRenderer, label,
                bx + bw / 2, by + bh / 2 - 3, 0xFFFFFF);
        }
    }

    // ── Mouse girişi ───────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn != 0) return super.mouseClicked(mx, my, btn);

        // Sağ panel — renk seçimi
        if (mx >= panelX()) {
            if (handleColorPick(mx, my)) return true;
        }
        // Sol panel — karakter bölgesi boyama
        else {
            handleCharacterPaint(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (btn == 0 && mx < panelX()) {
            handleCharacterPaint(mx, my);
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        if (mx >= panelX()) {
            brushRadius = Math.max(1, Math.min(8, brushRadius + (int) Math.signum(amount)));
            return true;
        }
        return super.mouseScrolled(mx, my, amount);
    }

    // ── Boyama mantığı ─────────────────────────────────────────────────────

    /**
     * FIX 5: Karakter bölgesine tıklandığında GERÇEKTEN boya uygular.
     * Grid koordinatları belirlenir → paintBrush çağrılır → PAINT_STROKE paketi gönderilir.
     */
    private void handleCharacterPaint(double mx, double my) {
        int cx = (panelX() - 10) / 2;
        int cy = this.height / 2 - 20;

        int headX = cx - HEAD_W / 2, headY = cy - HEAD_H - BODY_H / 2;
        int bodyX = cx - BODY_W / 2, bodyY = cy - BODY_H / 2;
        int rArmX = bodyX - ARM_W - 2, rArmY = bodyY;
        int lArmX = bodyX + BODY_W + 2, lArmY = bodyY;
        int rLegX = cx - BODY_W / 2, rLegY = bodyY + BODY_H + 1;
        int lLegX = cx, lLegY = bodyY + BODY_H + 1;

        if (inBounds(mx, my, headX, headY, HEAD_W, HEAD_H))
            paintPart(mx, my, headX, headY, HEAD_W, HEAD_H,  0, 0,  8, 8);
        else if (inBounds(mx, my, bodyX, bodyY, BODY_W, BODY_H))
            paintPart(mx, my, bodyX, bodyY, BODY_W, BODY_H, 8, 0, 8, 12);
        else if (inBounds(mx, my, rArmX, rArmY, ARM_W, ARM_H))
            paintPart(mx, my, rArmX, rArmY, ARM_W, ARM_H, 18, 0, 4, 12);
        else if (inBounds(mx, my, lArmX, lArmY, ARM_W, ARM_H))
            paintPart(mx, my, lArmX, lArmY, ARM_W, ARM_H, 22, 0, 4, 12);
        else if (inBounds(mx, my, rLegX, rLegY, LEG_W, LEG_H))
            paintPart(mx, my, rLegX, rLegY, LEG_W, LEG_H, 18, 12, 4, 12);
        else if (inBounds(mx, my, lLegX, lLegY, LEG_W, LEG_H))
            paintPart(mx, my, lLegX, lLegY, LEG_W, LEG_H, 22, 12, 4, 12);
    }

    /**
     * Ekran tıklama konumunu grid koordinatına çevirir ve boyar.
     */
    private void paintPart(double mx, double my,
                            int screenX, int screenY, int screenW, int screenH,
                            int gridStartX, int gridStartY, int gridW, int gridH) {
        // Tıklama → grid koordinatı
        int gx = gridStartX + (int)(((mx - screenX) / screenW) * gridW);
        int gy = gridStartY + (int)(((my - screenY) / screenH) * gridH);
        gx = Math.max(gridStartX, Math.min(gridStartX + gridW - 1, gx));
        gy = Math.max(gridStartY, Math.min(gridStartY + gridH - 1, gy));

        // Yerel veriyi güncelle (anlık önizleme için)
        getLocalData().paintBrush(gx, gy, brushRadius, currentColor);

        // HATA #6 DÜZELTMESİ: 50ms throttle — drag sırasında paket taşması önlenir
        long now = System.currentTimeMillis();
        if (now - lastPaintMs >= 50) {
            lastPaintMs = now;
            sendFill(gx, gy, brushRadius, currentColor);
        }
    }

    private boolean handleColorPick(double mx, double my) {
        Tab[] tabs = Tab.values();
        int px = panelX();
        int tw = (PANEL_W() - 4) / 4, th = TAB_H;
        int paletteY = 6 + 2 * (TAB_H + 2) + 6;
        int[] colors = activeColors();

        for (int i = 0; i < colors.length; i++) {
            int cx2 = px + 2 + (i % COLS) * SWATCH;
            int cy2 = paletteY + (i / COLS) * SWATCH;
            if (mx >= cx2 && mx < cx2 + SWATCH - 1 && my >= cy2 && my < cy2 + SWATCH - 1) {
                currentColor = colors[i];
                return true;
            }
        }
        return false;
    }

    // ── Ağ ─────────────────────────────────────────────────────────────────

    /** FIX 5: Sunucuya PAINT_STROKE paketi gönder. */
    private void sendFill(int cx, int cy, int radius, int color) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(cx);
        buf.writeInt(cy);
        buf.writeInt(radius);
        buf.writeInt(color);
        ClientPlayNetworking.send(ChameleonNetwork.PAINT_STROKE, buf);
    }

    // ── Yardımcılar ────────────────────────────────────────────────────────

    private int panelX()   { return this.width - PANEL_W(); }
    private int PANEL_W()  { return Math.min(140 + COLS * SWATCH, this.width / 3); }

    private PaintData getLocalData() {
        if (localData == null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) localData = PlayerPaintStore.getPaint(mc.player.getUuid());
        }
        return localData != null ? localData : new PaintData();
    }

    private int[] activeColors() {
        return switch (activeTab) {
            case MECCHA -> MECCHA; case TEMEL -> TEMEL; case DOGA -> DOGA;
            case TEN    -> TEN;   case PASTEL-> PASTEL; case NEON -> NEON;
            case KOYU   -> KOYU;  case TOPRAK-> TOPRAK;
        };
    }

    private String tabShort(Tab t) {
        return switch (t) {
            case MECCHA -> "MCC"; case TEMEL -> "TML"; case DOGA -> "DOĞ";
            case TEN    -> "TEN"; case PASTEL-> "PST"; case NEON -> "NON";
            case KOYU   -> "KYU"; case TOPRAK-> "TPR";
        };
    }

    private static boolean inBounds(double mx, double my, int bx, int by, int bw, int bh) {
        return mx >= bx && mx < bx + bw && my >= by && my < by + bh;
    }

    @Override public boolean shouldPause()     { return false; }
    @Override public boolean shouldCloseOnEsc(){ return true;  }
}
