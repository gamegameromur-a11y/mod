package com.chameleon.client;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Environment(EnvType.CLIENT)
public class ChameleonClient implements ClientModInitializer {

    public static KeyBinding poseNextKey;
    public static KeyBinding posePrevKey;
    public static KeyBinding paintToggleKey;

    private static final Identifier ID_GAME_STATE      = new Identifier("chameleon","game_state");
    private static final Identifier ID_GAME_RESULT     = new Identifier("chameleon","game_result");
    private static final Identifier ID_PLAYER_CAUGHT   = new Identifier("chameleon","player_caught");
    private static final Identifier ID_OPEN_MAP_SELECT = new Identifier("chameleon","open_map_select");

    // HATA #3 + Toggle için
    private static boolean prevCState = false;

    @Override
    public void onInitializeClient() {

        poseNextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chameleon.pose_next",  InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.chameleon"));
        posePrevKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chameleon.pose_prev",  InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.chameleon"));
        paintToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chameleon.paint_open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.chameleon"));

        // ── Tick ─────────────────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            if (poseNextKey.wasPressed()) changePose(client, true);
            if (posePrevKey.wasPressed()) changePose(client, false);

            boolean cNow  = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_C);
            if (cNow && !prevCState) {
                if (client.currentScreen instanceof PaintHudScreen) client.setScreen(null);
                else if (client.currentScreen == null)              client.setScreen(new PaintHudScreen());
            }
            prevCState = cNow;
        });

        // ── HUD ──────────────────────────────────────────────────────────────
        HudRenderCallback.EVENT.register((ctx, tickDelta) ->
                GameHudOverlay.render(ctx, net.minecraft.client.MinecraftClient.getInstance(), tickDelta));

        // HATA #5: Sunucudan ayrılınca serverPresent sıfırla
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            GameHudOverlay.serverPresent = false;
            GameClientState.stateId = 0;
            RoleManager.remove(client.player != null ? client.player.getUuid() : null);
        });

        // ── S→C Paket handlers ────────────────────────────────────────────────

        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.SYNC_PAINT,
                (client, handler, buf, resp) -> {
                    UUID uuid = buf.readUuid(); int[] cells = buf.readIntArray();
                    client.execute(() -> { PlayerPaintStore.setPaint(uuid, PaintData.fromRaw(cells)); WhiteSkinManager.cleanup(uuid); });
                });

        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.SYNC_POSE,
                (client, handler, buf, resp) -> {
                    UUID uuid = buf.readUuid(); int poseId = buf.readInt();
                    client.execute(() -> PlayerPaintStore.setPose(uuid, ChameleonPose.byId(poseId)));
                });

        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.SYNC_ROLE,
                (client, handler, buf, resp) -> {
                    UUID uuid = buf.readUuid(); int roleId = buf.readInt();
                    client.execute(() -> {
                        RoleManager.Role role = RoleManager.Role.byId(roleId);
                        RoleManager.setRole(uuid, role);
                        WhiteSkinManager.cleanup(uuid);
                        if (client.player != null && client.player.getUuid().equals(uuid)) {
                            String msg = switch (role) {
                                case HIDER  -> "§a[Chameleon] §lSAKLANAN §r§7— Boyalanıp gizlen! (½♥, düşme hasarı yok)";
                                case SEEKER -> "§c[Chameleon] §lYAKALAYICI §r§7— Güç V Sonsuzluk yay aldın!";
                                case NONE   -> "§7[Chameleon] Normal — Skin ve boyut sıfırlandı.";
                            };
                            client.player.sendMessage(net.minecraft.text.Text.literal(msg), false);
                        }
                    });
                });

        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.PLAYER_LEAVE,
                (client, handler, buf, resp) -> {
                    UUID uuid = buf.readUuid();
                    client.execute(() -> { WhiteSkinManager.cleanup(uuid); PlayerPaintStore.remove(uuid); RoleManager.remove(uuid); });
                });

        // ── Oyun durumu paketleri ─────────────────────────────────────────────

        ClientPlayNetworking.registerGlobalReceiver(ID_GAME_STATE,
                (client, handler, buf, resp) -> {
                    int stateId=buf.readInt(), timer=buf.readInt(), alive=buf.readInt(), total=buf.readInt();
                    client.execute(() -> {
                        GameClientState.stateId=stateId; GameClientState.timerSeconds=timer;
                        GameClientState.hidersAlive=alive; GameClientState.totalHiders=total;
                        GameClientState.lastUpdate=System.currentTimeMillis();
                        // HATA #5: sunucu paket gönderdi → flag set et
                        GameHudOverlay.serverPresent = true;
                    });
                });

        ClientPlayNetworking.registerGlobalReceiver(ID_GAME_RESULT,
                (client, handler, buf, resp) -> {
                    String winner = buf.readString();
                    client.execute(() -> GameClientState.winnerText = winner);
                });

        ClientPlayNetworking.registerGlobalReceiver(ID_PLAYER_CAUGHT,
                (client, handler, buf, resp) -> {
                    UUID uuid=buf.readUuid(); String name=buf.readString(); int left=buf.readInt();
                    client.execute(() -> {
                        GameClientState.hidersAlive=left;
                        GameClientState.caughtPlayerName=name;
                        GameClientState.caughtAt=System.currentTimeMillis();
                    });
                });

        ClientPlayNetworking.registerGlobalReceiver(ID_OPEN_MAP_SELECT,
                (client, handler, buf, resp) -> {
                    int count=buf.readInt();
                    List<String> names=new ArrayList<>(), descs=new ArrayList<>();
                    for(int i=0;i<count;i++){names.add(buf.readString());descs.add(buf.readString());}
                    client.execute(() -> {
                        GameClientState.mapNames.clear(); GameClientState.mapNames.addAll(names);
                        GameClientState.mapDescs.clear(); GameClientState.mapDescs.addAll(descs);
                        client.setScreen(new MapSelectScreen(names, descs));
                    });
                });
    }

    private static void changePose(net.minecraft.client.MinecraftClient client, boolean forward) {
        UUID uuid = client.player.getUuid();
        ChameleonPose next = forward ? PlayerPaintStore.getPose(uuid).next() : PlayerPaintStore.getPose(uuid).previous();
        PlayerPaintStore.setPose(uuid, next);
        PacketByteBuf buf = PacketByteBufs.create(); buf.writeInt(next.id);
        ClientPlayNetworking.send(ChameleonNetwork.POSE_CHANGE, buf);
        client.player.sendMessage(net.minecraft.text.Text.literal("§e[Chameleon] §fPoz: §b" + next.displayName), true);
    }
}
