package com.chameleon.client;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

@Environment(EnvType.CLIENT)
public class ChameleonClient implements ClientModInitializer {

    public static KeyBinding poseNextKey;
    public static KeyBinding posePrevKey;
    /** C tuşu — basılı tut: boya paneli aç; bırak: kamera kontrolü. */
    public static KeyBinding paintHoldKey;

    @Override
    public void onInitializeClient() {

        // ── Tuş atamaları ────────────────────────────────────────────────────
        poseNextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chameleon.pose_next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.chameleon"));
        posePrevKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chameleon.pose_prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.chameleon"));
        paintHoldKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chameleon.paint_open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.chameleon"));

        // ── Tick olayları ─────────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // V / B → poz değiştir
            if (poseNextKey.wasPressed()) changePose(client, true);
            if (posePrevKey.wasPressed()) changePose(client, false);

            // Düzeltme #5: C basılı tutulunca HUD paneli aç, bırakınca kapat.
            // Ekran yoksa veya PaintHudScreen dışında bir şey açıksa müdahale etme.
            boolean cHeld = InputUtil.isKeyPressed(
                    client.getWindow().getHandle(), GLFW.GLFW_KEY_C);
            boolean hudOpen = client.currentScreen instanceof PaintHudScreen;

            if (cHeld && !hudOpen && client.currentScreen == null) {
                client.setScreen(new PaintHudScreen());
            } else if (!cHeld && hudOpen) {
                client.setScreen(null);
            }
        });

        // ── S→C: Boya senkronu ────────────────────────────────────────────────
        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.SYNC_PAINT,
                (client, handler, buf, resp) -> {
                    UUID  uuid  = buf.readUuid();
                    int[] cells = buf.readIntArray();
                    client.execute(() -> {
                        PlayerPaintStore.setPaint(uuid, PaintData.fromRaw(cells));
                        WhiteSkinManager.cleanup(uuid); // cache geçersiz kıl
                    });
                });

        // ── S→C: Poz senkronu ─────────────────────────────────────────────────
        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.SYNC_POSE,
                (client, handler, buf, resp) -> {
                    UUID uuid   = buf.readUuid();
                    int  poseId = buf.readInt();
                    client.execute(() ->
                            PlayerPaintStore.setPose(uuid, ChameleonPose.byId(poseId)));
                });

        // ── S→C: Rol senkronu ─────────────────────────────────────────────────
        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.SYNC_ROLE,
                (client, handler, buf, resp) -> {
                    UUID uuid   = buf.readUuid();
                    int  roleId = buf.readInt();
                    client.execute(() -> {
                        RoleManager.Role role = RoleManager.Role.byId(roleId);
                        RoleManager.setRole(uuid, role);
                        // Yerel oyuncuya bildirim
                        if (client.player != null && client.player.getUuid().equals(uuid)) {
                            client.player.sendMessage(
                                net.minecraft.text.Text.literal(
                                    "§e[Chameleon] §fRol: §b" + role.displayName), true);
                        }
                    });
                });

        // ── S→C: Oyuncu ayrıldı — texture temizle (Düzeltme #7) ──────────────
        ClientPlayNetworking.registerGlobalReceiver(ChameleonNetwork.PLAYER_LEAVE,
                (client, handler, buf, resp) -> {
                    UUID uuid = buf.readUuid();
                    client.execute(() -> {
                        WhiteSkinManager.cleanup(uuid);       // GPU texture'ı serbest bırak
                        PlayerPaintStore.remove(uuid);         // boya + poz verisi
                        RoleManager.remove(uuid);              // rol verisi
                    });
                });
    }

    // ── Yardımcı ─────────────────────────────────────────────────────────────

    private static void changePose(net.minecraft.client.MinecraftClient client, boolean forward) {
        UUID uuid = client.player.getUuid();
        ChameleonPose next = forward
                ? PlayerPaintStore.getPose(uuid).next()
                : PlayerPaintStore.getPose(uuid).previous();
        PlayerPaintStore.setPose(uuid, next);

        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(next.id);
        ClientPlayNetworking.send(ChameleonNetwork.POSE_CHANGE, buf);

        client.player.sendMessage(
                net.minecraft.text.Text.literal("§e[Chameleon] §fPoz: §b" + next.displayName), true);
    }
}
