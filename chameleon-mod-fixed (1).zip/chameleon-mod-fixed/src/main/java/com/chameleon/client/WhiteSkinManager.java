package com.chameleon.client;

import com.chameleon.paint.PaintData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Her oyuncu için dinamik beyaz + boyalı texture üretir.
 *
 * Düzeltme #7 (Texture bellek sızıntısı):
 *   cleanup(uuid) artık sunucu PLAYER_LEAVE paketi alındığında
 *   ChameleonClient tarafından otomatik çağrılıyor.
 *   Bu sayede oyuncu ayrıldıktan sonra GPU'da atıl texture kalmıyor.
 *
 * Düzeltme #2 türevi: HashMap → ConcurrentHashMap (thread safety).
 */
@Environment(EnvType.CLIENT)
public class WhiteSkinManager {

    private static final Map<UUID, Identifier> dynamicTextures = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer>    lastHash        = new ConcurrentHashMap<>();

    private static final int SKIN_W = 64;
    private static final int SKIN_H = 64;

    /**
     * Oyuncu için güncel texture identifier döndür.
     * PaintData değişmişse texture'ı otomatik yeniden oluşturur.
     */
    public static Identifier getTexture(UUID uuid, PaintData paintData) {
        int hash = java.util.Arrays.hashCode(paintData.getRawCells());
        Integer prev = lastHash.get(uuid);

        if (prev != null && prev == hash && dynamicTextures.containsKey(uuid)) {
            return dynamicTextures.get(uuid);
        }

        Identifier id = buildTexture(uuid, paintData);
        lastHash.put(uuid, hash);
        return id;
    }

    private static Identifier buildTexture(UUID uuid, PaintData paintData) {
        MinecraftClient client = MinecraftClient.getInstance();

        NativeImage img = new NativeImage(NativeImage.Format.RGBA, SKIN_W, SKIN_H, false);

        // 1. Tüm pikselleri beyaza doldur
        for (int y = 0; y < SKIN_H; y++)
            for (int x = 0; x < SKIN_W; x++)
                img.setColor(x, y, 0xFFFFFFFF);

        // 2. PaintData renklerini Steve UV haritasına uygula
        applyPaintToSkin(img, paintData);

        // 3. Eski texture varsa GPU'dan serbest bırak
        Identifier id = new Identifier("chameleon", "skin_" + uuid.toString().replace("-", ""));
        if (dynamicTextures.containsKey(uuid)) {
            client.getTextureManager().destroyTexture(dynamicTextures.get(uuid));
        }

        // 4. Yeni texture GPU'ya yükle
        NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
        client.getTextureManager().registerTexture(id, tex);
        dynamicTextures.put(uuid, id);
        return id;
    }

    /**
     * Steve UV haritası (Minecraft 1.8+ format):
     * {skinX, skinY, skinW, skinH, gridX, gridY, gridW, gridH}
     *
     * PaintData grid: 32×64 mantıksal hücre
     */
    private static void applyPaintToSkin(NativeImage img, PaintData paintData) {
        int[][] regions = {
            // Kafa ön
            {8,  8,  8, 8,   0,  0, 16, 16},
            // Gövde ön
            {20, 20, 8, 12,  0, 16, 16, 24},
            // Sağ kol ön
            {44, 20, 4, 12,  0, 40,  8, 24},
            // Sol kol ön (1.8+)
            {36, 52, 4, 12, 24, 40,  8, 24},
            // Sağ bacak ön
            {4,  20, 4, 12,  8, 40,  8, 24},
            // Sol bacak ön (1.8+)
            {20, 52, 4, 12, 16, 40,  8, 24},
        };

        for (int[] r : regions) {
            int skinX = r[0], skinY = r[1], skinW = r[2], skinH = r[3];
            int gridX = r[4], gridY = r[5], gridW = r[6], gridH = r[7];

            for (int py = 0; py < skinH; py++) {
                for (int px = 0; px < skinW; px++) {
                    int gx = Math.min(gridX + (int)((float)px / skinW * gridW), PaintData.GRID_W - 1);
                    int gy = Math.min(gridY + (int)((float)py / skinH * gridH), PaintData.GRID_H - 1);
                    img.setColor(skinX + px, skinY + py, argbToAbgr(paintData.getCell(gx, gy)));
                }
            }
        }
    }

    /** ARGB → ABGR (NativeImage byte sırası) */
    private static int argbToAbgr(int argb) {
        int a = (argb >> 24) & 0xFF, r = (argb >> 16) & 0xFF,
            g = (argb >>  8) & 0xFF, b = (argb      ) & 0xFF;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    /**
     * Texture cache'ini temizle ve GPU belleğini serbest bırak.
     * Düzeltme #7: ChameleonClient, PLAYER_LEAVE paketi geldiğinde bu metodu çağırır.
     */
    public static void cleanup(UUID uuid) {
        Identifier id = dynamicTextures.remove(uuid);
        if (id != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) mc.getTextureManager().destroyTexture(id);
        }
        lastHash.remove(uuid);
    }
}
