package com.chameleon.client;

import com.chameleon.paint.PaintData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * HATA #2 DÜZELTMESİ — Dış katman (jacket/hat) iç katmanı örtüyordu.
 *
 * Eski kod: tüm 64×64 pikseli 0xFFFFFFFF (opak beyaz) ile başlatıyordu.
 * Sonuç: dış katman (y=32-48 jacket, y=0-16 x=32-64 hat, vb.) da opak beyaz
 *         olduğundan boyalı iç katmanı tamamen kapatıyordu → boyama görünmez.
 *
 * Yeni yaklaşım:
 *   1. Tüm pikseller → şeffaf (0x00000000)
 *   2. Sadece iç katman bölgeleri → opak beyaz (0xFFFFFFFF) ile doldur
 *   3. Boya verilerini iç katman bölgelerine yaz
 *   4. Dış katman pikselleri şeffaf kalır → iç katman görünür
 *
 * HATA #11 DÜZELTMESİ — Yan yüzler de boyanıyor.
 * Önceki kod sadece ön ve arka yüzleri işliyordu.
 * Şimdi sol/sağ yan yüzler de aynı grid rengiyle boyanıyor.
 */
@Environment(EnvType.CLIENT)
public class WhiteSkinManager {

    private static final Map<UUID, Identifier> textureCache = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer>    hashCache    = new ConcurrentHashMap<>();

    private static final int SKIN_W = 64;
    private static final int SKIN_H = 64;

    public static Identifier getTexture(UUID uuid, PaintData data) {
        int hash = Arrays.hashCode(data.getRawCells());
        Integer prev = hashCache.get(uuid);
        if (prev != null && prev == hash && textureCache.containsKey(uuid))
            return textureCache.get(uuid);
        return buildAndCache(uuid, data, hash);
    }

    private static Identifier buildAndCache(UUID uuid, PaintData data, int hash) {
        MinecraftClient mc = MinecraftClient.getInstance();

        NativeImage img = new NativeImage(NativeImage.Format.RGBA, SKIN_W, SKIN_H, false);

        // HATA #2 FIX: Adım 1 — Her piksel şeffaf başlıyor
        for (int y = 0; y < SKIN_H; y++)
            for (int x = 0; x < SKIN_W; x++)
                img.setColor(x, y, 0x00000000);

        // Adım 2 — Sadece iç katman bölgelerini opak beyazla doldur
        fillInnerLayers(img);

        // Adım 3 — Boya verilerini iç katmana uygula
        applyPaint(img, data);

        // Eski texture'ı GPU'dan sil
        Identifier id = new Identifier("chameleon",
                "skin_" + uuid.toString().replace("-", ""));
        Identifier old = textureCache.get(uuid);
        if (old != null) mc.getTextureManager().destroyTexture(old);

        mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
        textureCache.put(uuid, id);
        hashCache.put(uuid, hash);
        return id;
    }

    /**
     * Sadece iç katman alanlarını opak beyazla doldur.
     * Dış katman (jacket, hat, outer arm/leg) şeffaf kalır.
     *
     * Steve iç katman bölgeleri (64×64 layout):
     *   Head   : x=0-32,  y=0-16
     *   Body   : x=16-40, y=16-32
     *   R.Arm  : x=40-56, y=16-32
     *   R.Leg  : x=0-16,  y=16-32
     *   L.Arm  : x=32-48, y=48-64  (1.8+ format)
     *   L.Leg  : x=16-32, y=48-64  (1.8+ format)
     */
    private static void fillInnerLayers(NativeImage img) {
        fillRect(img, 0,  0,  32, 16);  // head inner
        fillRect(img, 0,  16, 64, 16);  // body + R.arm + R.leg inner (y=16-32)
        fillRect(img, 16, 48, 32, 16);  // L.arm + L.leg inner (y=48-64)
    }

    private static void fillRect(NativeImage img, int x, int y, int w, int h) {
        for (int py = y; py < y + h; py++)
            for (int px = x; px < x + w; px++)
                img.setColor(px, py, abgr(0xFFFFFFFF));
    }

    /**
     * Boya verilerini Steve UV iç katman bölgelerine yaz.
     * {skinX, skinY, skinW, skinH, gridX, gridY, gridW, gridH}
     *
     * HATA #11 FIX: Yan yüzler (sol/sağ) eklendi — aynı grid rengiyle boyanıyor.
     */
    private static void applyPaint(NativeImage img, PaintData data) {

        int[][] regions = {
            // ── Baş — tüm 6 yüz ──────────────────────────────────────────────
            {  8,  8,  8,  8,    0,  0,  8,  8 },  // ön
            { 24,  8,  8,  8,    0,  0,  8,  8 },  // arka
            { 16,  8,  8,  8,    0,  0,  8,  8 },  // sağ yan
            {  0,  8,  8,  8,    0,  0,  8,  8 },  // sol yan
            {  8,  0,  8,  8,    0,  0,  8,  8 },  // üst
            { 16,  0,  8,  8,    0,  0,  8,  8 },  // alt

            // ── Gövde — tüm 6 yüz ────────────────────────────────────────────
            { 20, 20,  8, 12,    8,  0,  8, 12 },  // ön
            { 32, 20,  8, 12,    8,  0,  8, 12 },  // arka
            { 16, 20,  4, 12,    8,  0,  4, 12 },  // sağ yan
            { 28, 20,  4, 12,    8,  0,  4, 12 },  // sol yan
            { 20, 16,  8,  4,    8,  0,  8,  4 },  // üst
            { 28, 16,  8,  4,    8,  0,  8,  4 },  // alt

            // ── Sağ kol — tüm 6 yüz ──────────────────────────────────────────
            { 44, 20,  4, 12,   18,  0,  4, 12 },  // ön
            { 52, 20,  4, 12,   18,  0,  4, 12 },  // arka
            { 40, 20,  4, 12,   18,  0,  4, 12 },  // sağ
            { 48, 20,  4, 12,   18,  0,  4, 12 },  // sol
            { 44, 16,  4,  4,   18,  0,  4,  4 },  // üst
            { 48, 16,  4,  4,   18,  0,  4,  4 },  // alt

            // ── Sol kol (1.8+) — tüm 6 yüz ───────────────────────────────────
            { 36, 52,  4, 12,   22,  0,  4, 12 },  // ön
            { 44, 52,  4, 12,   22,  0,  4, 12 },  // arka
            { 32, 52,  4, 12,   22,  0,  4, 12 },  // sağ
            { 40, 52,  4, 12,   22,  0,  4, 12 },  // sol
            { 36, 48,  4,  4,   22,  0,  4,  4 },  // üst
            { 40, 48,  4,  4,   22,  0,  4,  4 },  // alt

            // ── Sağ bacak — tüm 6 yüz ────────────────────────────────────────
            {  4, 20,  4, 12,   18, 12,  4, 12 },  // ön
            { 12, 20,  4, 12,   18, 12,  4, 12 },  // arka
            {  0, 20,  4, 12,   18, 12,  4, 12 },  // sağ
            {  8, 20,  4, 12,   18, 12,  4, 12 },  // sol
            {  4, 16,  4,  4,   18, 12,  4,  4 },  // üst
            {  8, 16,  4,  4,   18, 12,  4,  4 },  // alt

            // ── Sol bacak (1.8+) — tüm 6 yüz ─────────────────────────────────
            { 20, 52,  4, 12,   22, 12,  4, 12 },  // ön
            { 28, 52,  4, 12,   22, 12,  4, 12 },  // arka
            { 16, 52,  4, 12,   22, 12,  4, 12 },  // sağ
            { 24, 52,  4, 12,   22, 12,  4, 12 },  // sol
            { 20, 48,  4,  4,   22, 12,  4,  4 },  // üst
            { 24, 48,  4,  4,   22, 12,  4,  4 },  // alt
        };

        for (int[] r : regions) {
            int sx = r[0], sy = r[1], sw = r[2], sh = r[3];
            int gx = r[4], gy = r[5], gw = r[6], gh = r[7];
            for (int py = 0; py < sh; py++) {
                for (int px = 0; px < sw; px++) {
                    int gc = Math.min(gx + (int)((float)px/sw*gw), gx+gw-1);
                    int gr = Math.min(gy + (int)((float)py/sh*gh), gy+gh-1);
                    img.setColor(sx + px, sy + py, abgr(data.getCell(gc, gr)));
                }
            }
        }
    }

    /** ARGB → ABGR (NativeImage byte sırası). */
    private static int abgr(int argb) {
        int a=(argb>>24)&0xFF, r=(argb>>16)&0xFF, g=(argb>>8)&0xFF, b=argb&0xFF;
        return (a<<24)|(b<<16)|(g<<8)|r;
    }

    public static void cleanup(UUID uuid) {
        Identifier id = textureCache.remove(uuid);
        if (id != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) mc.getTextureManager().destroyTexture(id);
        }
        hashCache.remove(uuid);
    }
}
