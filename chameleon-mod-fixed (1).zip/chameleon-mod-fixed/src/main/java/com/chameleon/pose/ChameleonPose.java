package com.chameleon.pose;

/**
 * Oyuncunun alabileceği 6 poz.
 * Her pozun render için pitch/yaw/scale ve eklem açıları farklı.
 */
public enum ChameleonPose {

    STAND(0, "Düz Dur"),         // varsayılan dik duruş
    PRONE(1, "Yere Uzan"),       // yüzüstü yatma
    SIDE_LAY(2, "Yan Yat"),      // yan yatma
    CROUCH_CUSTOM(3, "Çömel"),   // vanilla'dan farklı özel çömelme
    FETAL(4, "Top Ol"),          // fetal pozisyon — top gibi kıvrıl
    WALL_HUG(5, "Duvara Yapış"); // duvara düz yapış

    public final int id;
    public final String displayName;

    ChameleonPose(int id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public static ChameleonPose byId(int id) {
        for (ChameleonPose p : values()) {
            if (p.id == id) return p;
        }
        return STAND;
    }

    public ChameleonPose next() {
        ChameleonPose[] vals = values();
        return vals[(this.ordinal() + 1) % vals.length];
    }

    public ChameleonPose previous() {
        ChameleonPose[] vals = values();
        return vals[(this.ordinal() - 1 + vals.length) % vals.length];
    }
}
