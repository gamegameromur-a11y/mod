package com.chameleon.role;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Oyuncu rollerini yönetir.
 * Hem sunucu hem istemci tarafında kullanılır;
 * istemci senkronizasyonu SYNC_ROLE paketiyle yapılır.
 *
 * Roller:
 *   NONE   — Normal oyun, rol yok
 *   HIDER  — Saklanan: ½ kalp HP, düşme hasarı yok, yakalayıcılar isim etiketini göremez
 *   SEEKER — Yakalayıcı: Güç 5 yay alır, saklananların isim etiketini göremez
 */
public class RoleManager {

    public enum Role {
        NONE  (0, "Normal"),
        HIDER (1, "Saklanan"),
        SEEKER(2, "Yakalayıcı");

        public final int    id;
        public final String displayName;

        Role(int id, String displayName) {
            this.id = id;
            this.displayName = displayName;
        }

        public static Role byId(int id) {
            for (Role r : values()) if (r.id == id) return r;
            return NONE;
        }
    }

    private static final Map<UUID, Role> roleMap = new ConcurrentHashMap<>();

    public static Role getRole(UUID uuid)         { return roleMap.getOrDefault(uuid, Role.NONE); }
    public static void setRole(UUID uuid, Role r)  { roleMap.put(uuid, r); }
    public static void remove(UUID uuid)           { roleMap.remove(uuid); }

    public static boolean isHider (UUID uuid) { return getRole(uuid) == Role.HIDER;  }
    public static boolean isSeeker(UUID uuid) { return getRole(uuid) == Role.SEEKER; }
}
