package com.chameleon.role;

import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * HATA #7 DÜZELTMESİ — Yay/ok kontrolsüz tekrar veriliyordu.
 *
 * Eski kod: apply(SEEKER) her çağrıldığında envantere 1 yay + 1 ok ekliyordu.
 * Sonuç: /cham role seeker iki kez → 2 yay, 2 ok. Daha fazla yazılınca stok birikir.
 *
 * Düzeltme: Envanterde zaten Güç V yay varsa yeni yay VERİLMEZ.
 *           Ok sayısı 1'den azsa tamamlanır.
 */
public final class RoleEffects {

    private RoleEffects() {}

    public static void apply(ServerPlayerEntity player, RoleManager.Role role) {
        switch (role) {
            case HIDER -> {
                EntityAttributeInstance maxHp =
                        player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                if (maxHp != null) maxHp.setBaseValue(1.0);
                player.setHealth(1.0f);
            }
            case SEEKER -> {
                // HATA #7: Envanterde Güç yayı var mı kontrol et
                boolean hasPowerBow = false;
                boolean hasArrow    = false;
                for (int i = 0; i < player.getInventory().size(); i++) {
                    ItemStack stack = player.getInventory().getStack(i);
                    if (!stack.isEmpty()) {
                        if (stack.isOf(Items.BOW) && stack.getEnchantments().getSize() > 0)
                            hasPowerBow = true;
                        if (stack.isOf(Items.ARROW))
                            hasArrow = true;
                    }
                }
                // Yay yoksa ver
                if (!hasPowerBow) {
                    ItemStack bow = new ItemStack(Items.BOW);
                    bow.addEnchantment(Enchantments.POWER,    5);
                    bow.addEnchantment(Enchantments.INFINITY, 1);
                    if (!player.getInventory().insertStack(bow))
                        player.dropItem(bow, false);
                }
                // Ok yoksa ver
                if (!hasArrow) {
                    ItemStack arrow = new ItemStack(Items.ARROW, 1);
                    if (!player.getInventory().insertStack(arrow))
                        player.dropItem(arrow, false);
                }
            }
            default -> { }
        }
    }

    public static void reset(ServerPlayerEntity player, RoleManager.Role oldRole) {
        if (oldRole == RoleManager.Role.HIDER) {
            EntityAttributeInstance maxHp =
                    player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (maxHp != null) maxHp.setBaseValue(20.0);
            player.setHealth(20.0f);
        }
    }
}
