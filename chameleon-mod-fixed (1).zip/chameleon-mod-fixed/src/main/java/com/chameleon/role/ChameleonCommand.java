package com.chameleon.role;

import com.chameleon.network.ChameleonNetwork;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Komutlar:
 *   /cham role hider   — Saklanan ol (½ kalp, düşme hasarı yok)
 *   /cham role seeker  — Yakalayıcı ol (Güç V + Sonsuzluk yay + 1 ok)
 *   /cham role none    — Normal moda dön (FIX 2: skin ve boyut sıfırlanır)
 */
public class ChameleonCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
            CommandManager.literal("cham")
                .then(CommandManager.literal("role")
                    .then(CommandManager.literal("hider")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.HIDER)))
                    .then(CommandManager.literal("seeker")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.SEEKER)))
                    .then(CommandManager.literal("none")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.NONE)))
                )
        );
    }

    private static int setRole(CommandContext<ServerCommandSource> ctx,
                                RoleManager.Role newRole) {
        ServerCommandSource source = ctx.getSource();
        ServerPlayerEntity player;
        try { player = source.getPlayerOrThrow(); }
        catch (Exception e) {
            source.sendError(Text.literal("§c[Chameleon] Sadece oyuncular kullanabilir."));
            return 0;
        }

        RoleManager.Role oldRole = RoleManager.getRole(player.getUuid());

        // FIX 2: Eski rol etkilerini temizle (boyut ve can sıfırla)
        RoleEffects.reset(player, oldRole);

        // Yeni rolü kaydet ve efektleri uygula
        RoleManager.setRole(player.getUuid(), newRole);
        RoleEffects.apply(player, newRole);

        // Tüm istemcilere bildir (nametag + skin + render için)
        broadcastRoleSync(player, newRole);

        // Oyuncuya chat mesajı
        player.sendMessage(
            Text.literal("§e[Chameleon] §fRol: §b" + newRole.displayName), false);
        return 1;
    }

    /** Tüm istemcilere SYNC_ROLE paketi gönder. */
    public static void broadcastRoleSync(ServerPlayerEntity changed, RoleManager.Role role) {
        if (changed.getServer() == null) return;
        changed.getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(changed.getUuid());
            buf.writeInt(role.id);
            ServerPlayNetworking.send(p, ChameleonNetwork.SYNC_ROLE, buf);
        });
    }
}
