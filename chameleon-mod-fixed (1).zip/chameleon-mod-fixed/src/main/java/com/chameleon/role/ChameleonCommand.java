package com.chameleon.role;

import com.chameleon.network.ChameleonNetwork;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Komutlar:
 *   /cham role hider   — Saklanan ol (½ kalp, düşme hasarı yok)
 *   /cham role seeker  — Yakalayıcı ol (Güç V yay)
 *   /cham role none    — Normal moda dön
 */
public class ChameleonCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
            CommandManager.literal("cham")
                .then(CommandManager.literal("role")
                    .then(CommandManager.literal("hider")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.HIDER)))
                    .then(CommandManager.literal("seeker")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.SEEKER)))
                    .then(CommandManager.literal("none")
                        .executes(ctx -> setRole(ctx, RoleManager.Role.NONE)))
                )
        );
    }

    private static int setRole(CommandContext<ServerCommandSource> ctx, RoleManager.Role newRole) {
        ServerCommandSource source = ctx.getSource();
        ServerPlayerEntity player;
        try {
            player = source.getPlayerOrThrow();
        } catch (Exception e) {
            source.sendError(Text.literal("[Chameleon] Bu komut sadece oyuncular tarafından kullanılabilir."));
            return 0;
        }

        RoleManager.Role oldRole = RoleManager.getRole(player.getUuid());

        // Eski rolün etkilerini sıfırla
        resetEffects(player, oldRole);

        // Yeni rolü uygula
        RoleManager.setRole(player.getUuid(), newRole);
        applyEffects(player, newRole);

        // Tüm istemcilere rol değişikliğini bildir
        broadcastRoleSync(player, newRole);

        // Oyuncuya bildir
        player.sendMessage(
            Text.literal("§e[Chameleon] §fRol: §b" + newRole.displayName), false);

        return 1;
    }

    // ── Rol etkileri ─────────────────────────────────────────────────────────

    private static void resetEffects(ServerPlayerEntity player, RoleManager.Role oldRole) {
        if (oldRole == RoleManager.Role.HIDER) {
            // Maksimum canı 20'ye geri getir
            EntityAttributeInstance maxHp =
                player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (maxHp != null) maxHp.setBaseValue(20.0);
            player.setHealth(20.0f);
        }
    }

    private static void applyEffects(ServerPlayerEntity player, RoleManager.Role role) {
        switch (role) {
            case HIDER -> {
                // Yarım kalp (1 HP) ve sınırlı maksimum can
                EntityAttributeInstance maxHp =
                    player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
                if (maxHp != null) maxHp.setBaseValue(1.0);
                player.setHealth(1.0f);
            }
            case SEEKER -> {
                // Güç V + Sonsuzluk yayı ver
                // Not: Sonsuzluk büyüsü okları tüketmez ama çalışması için
                //      envanterde en az 1 ok bulunması gerekir — 1 ok da ekleniyor.
                ItemStack bow = new ItemStack(Items.BOW);
                bow.addEnchantment(Enchantments.POWER,    5);
                bow.addEnchantment(Enchantments.INFINITY, 1);
                if (!player.getInventory().insertStack(bow)) {
                    player.dropItem(bow, false);
                }
                // Sonsuzluk için zorunlu olan 1 ok
                ItemStack arrow = new ItemStack(net.minecraft.item.Items.ARROW, 1);
                if (!player.getInventory().insertStack(arrow)) {
                    player.dropItem(arrow, false);
                }
            }
            default -> { /* NONE — efekt yok */ }
        }
    }

    // ── Ağ ───────────────────────────────────────────────────────────────────

    /**
     * Tüm bağlı oyunculara UUID + rol ID gönder.
     * İstemciler bu paketi alınca kendi RoleManager'larını günceller.
     */
    public static void broadcastRoleSync(ServerPlayerEntity changed, RoleManager.Role role) {
        if (changed.getServer() == null) return;
        changed.getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(changed.getUuid());
            buf.writeInt(role.id);
            ServerPlayNetworking.send(p, ChameleonNetwork.SYNC_ROLE, buf);
        });
    }
}
