package com.chameleon.mixin;

import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * İsim etiketi (nametag) görünürlüğünü role göre kontrol eder.
 *
 * Kurallar:
 *   YAKALAYICI → SAKLANAN  : isim etiketi GİZLİ
 *   YAKALAYICI → YAKALAYICI: görünür
 *   SAKLANAN   → herkese   : görünür
 *   ROL YOK    → herkese   : normal davranış (görünür)
 */
@Environment(EnvType.CLIENT)
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {

    @Inject(method = "renderLabelIfPresent",
            at = @At("HEAD"),
            cancellable = true)
    private void chameleonHideNametag(Entity entity,
                                      Text text,
                                      MatrixStack matrices,
                                      VertexConsumerProvider vertexConsumers,
                                      int light,
                                      CallbackInfo ci) {

        // Yalnızca oyuncu varlıkları için kontrol yap
        if (!(entity instanceof PlayerEntity)) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        RoleManager.Role viewerRole = RoleManager.getRole(client.player.getUuid());
        RoleManager.Role targetRole = RoleManager.getRole(entity.getUuid());

        // Yakalayıcılar saklananların etiketini göremez
        if (viewerRole == RoleManager.Role.SEEKER && targetRole == RoleManager.Role.HIDER) {
            ci.cancel();
        }
        // Diğer tüm kombinasyonlar normal şekilde görünür
    }
}
