package com.chameleon.mixin;

import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * HATA #1 DÜZELTMESİ: Generic tip kaldırıldı.
 * Önceki kod <T extends LivingEntity> kullanıyordu → setAngles hedefi belirsiz,
 * Mixin derleme ya da runtime'da başarısız oluyordu.
 * Şimdi AbstractClientPlayerEntity doğrudan kullanılıyor.
 */
@Environment(EnvType.CLIENT)
@Mixin(PlayerEntityModel.class)
public class PlayerModelMixin {

    @Shadow public ModelPart head;
    @Shadow public ModelPart body;
    @Shadow public ModelPart rightArm;
    @Shadow public ModelPart leftArm;
    @Shadow public ModelPart rightLeg;
    @Shadow public ModelPart leftLeg;
    @Shadow public ModelPart hat;

    /**
     * setAngles SONRASINA inject et — vanilla animasyonu çalıştı,
     * biz üstüne yazıyoruz. Önceki kod render() içindeydi ve ezileniyordu.
     *
     * Descriptor açık belirtildi: belirsiz method match hatasını önler.
     */
    @Inject(
        method = "setAngles(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFFFF)V",
        at = @At("RETURN")
    )
    private void applyCustomPose(AbstractClientPlayerEntity entity,
                                  float limbAngle, float limbDistance,
                                  float animProgress, float headYaw, float headPitch,
                                  CallbackInfo ci) {

        RoleManager.Role role = RoleManager.getRole(entity.getUuid());
        if (role == RoleManager.Role.NONE) return;

        ChameleonPose pose = PlayerPaintStore.getPose(entity.getUuid());
        if (pose == ChameleonPose.STAND) return;

        resetAll();

        switch (pose) {
            case PRONE         -> applyProne();
            case SIDE_LAY      -> applySideLay();
            case CROUCH_CUSTOM -> applyCrouchCustom(headPitch);
            case FETAL         -> applyFetal();
            case WALL_HUG      -> applyWallHug(headPitch);
        }
    }

    private void resetAll() {
        head.pitch = 0; head.yaw = 0; head.roll = 0;
        body.pitch = 0; body.yaw = 0; body.roll = 0;
        rightArm.pitch = 0; rightArm.roll = 0; rightArm.yaw = 0;
        leftArm.pitch  = 0; leftArm.roll  = 0; leftArm.yaw  = 0;
        rightLeg.pitch = 0; rightLeg.roll = 0;
        leftLeg.pitch  = 0; leftLeg.roll  = 0;
        // Hat: bağımsız sıfırlama (copyTransform head pivot'unu bozuyordu)
        hat.pitch = 0; hat.yaw = 0; hat.roll = 0;
    }

    private void applyProne() {
        body.pitch     = rad(90);
        head.pitch     = rad(-90);
        hat.pitch      = head.pitch;
        rightArm.pitch = rad(-160); rightArm.roll = rad(-20);
        leftArm.pitch  = rad(-160); leftArm.roll  = rad( 20);
        rightLeg.pitch = rad(-10);
        leftLeg.pitch  = rad(-10);
    }

    private void applySideLay() {
        body.roll  = rad(-90);
        head.roll  = rad(-90); hat.roll = head.roll;
        rightArm.roll = rad(-90);
        leftArm.roll  = rad(-90);
        rightLeg.roll = rad(-15); rightLeg.pitch = rad(10);
        leftLeg.roll  = rad(-25); leftLeg.pitch  = rad(-10);
    }

    private void applyCrouchCustom(float headPitch) {
        body.pitch     = rad(40);
        head.pitch     = rad(-35) + headPitch; hat.pitch = head.pitch;
        rightArm.pitch = rad(-50); rightArm.roll = rad( 15);
        leftArm.pitch  = rad(-50); leftArm.roll  = rad(-15);
        rightLeg.pitch = rad(50);
        leftLeg.pitch  = rad(50);
    }

    private void applyFetal() {
        body.pitch     = rad(70);
        head.pitch     = rad(-60); hat.pitch = head.pitch;
        rightArm.pitch = rad(-120); rightArm.roll = rad( 30);
        leftArm.pitch  = rad(-120); leftArm.roll  = rad(-30);
        rightLeg.pitch = rad(130);  rightLeg.roll = rad( 10);
        leftLeg.pitch  = rad(130);  leftLeg.roll  = rad(-10);
    }

    private void applyWallHug(float headPitch) {
        body.pitch     = rad(-20);
        head.pitch     = rad(15) + headPitch; hat.pitch = head.pitch;
        rightArm.pitch = rad(-170); rightArm.roll = rad( 25);
        leftArm.pitch  = rad(-170); leftArm.roll  = rad(-25);
        rightLeg.pitch = rad(10);
        leftLeg.pitch  = rad(10);
    }

    private static float rad(float deg) { return (float) Math.toRadians(deg); }
}
