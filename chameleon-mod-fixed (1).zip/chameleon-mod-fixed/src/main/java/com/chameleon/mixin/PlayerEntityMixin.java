package com.chameleon.mixin;

import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.role.RoleManager;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ServerPlayerEntity mixin:
 *
 *  • NBT persist (Düzeltme #4):
 *      readCustomDataFromNbt  → Chameleon verisini yükle
 *      writeCustomDataToNbt   → Chameleon verisini kaydet
 *
 *  • Düşme hasarı engeli (Saklananlar için, Düzeltme #6 / rol sistemi):
 *      handleFallDamage       → HIDER rolündeyse hasarı engelle
 *
 *  • Oyuncu ayrılınca temizlik:
 *      onDisconnect           → sunucu verilerini sil
 *
 *  NOT: Düzeltme #3 — Bağlanma senkronu onSpawn yerine artık
 *       ChameleonMod içindeki ServerPlayConnectionEvents.JOIN event'inde
 *       yapılmaktadır. onSpawn reconnect'te çağrılmıyordu.
 */
@Mixin(ServerPlayerEntity.class)
public class PlayerEntityMixin {

    // ── NBT: Yükleme (Düzeltme #4) ────────────────────────────────────────────

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onLoadNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        if (nbt.contains("ChameleonData")) {
            PlayerPaintStore.loadPlayer(self.getUuid(), nbt.getCompound("ChameleonData"));
        }
    }

    // ── NBT: Kaydetme (Düzeltme #4) ───────────────────────────────────────────

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onSaveNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        nbt.put("ChameleonData", PlayerPaintStore.savePlayer(self.getUuid()));
    }

    // ── Düşme hasarı engeli (HIDER rolü) ──────────────────────────────────────

    /**
     * Saklananlar düşme hasarı almaz.
     * Düzeltme: Düşme hasarı → false dönerek hasarı iptal eder.
     */
    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true)
    private void preventFallDamageForHider(float fallDistance, float damageMultiplier,
                                           DamageSource source,
                                           CallbackInfoReturnable<Boolean> cir) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        if (RoleManager.isHider(self.getUuid())) {
            cir.setReturnValue(false);  // hasarı engelle
            cir.cancel();
        }
    }

    // ── Ayrılma temizliği ─────────────────────────────────────────────────────

    @Inject(method = "onDisconnect", at = @At("TAIL"))
    private void onPlayerLeave(CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        // Sunucu taraflı verileri temizle
        // İstemci taraflı texture temizliği için ChameleonMod PLAYER_LEAVE paketi yollar
        PlayerPaintStore.remove(self.getUuid());
        RoleManager.remove(self.getUuid());
    }
}
