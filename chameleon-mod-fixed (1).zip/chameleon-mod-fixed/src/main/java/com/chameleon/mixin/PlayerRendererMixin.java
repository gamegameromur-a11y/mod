package com.chameleon.mixin;

import com.chameleon.client.WhiteSkinManager;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(PlayerEntityRenderer.class)
public class PlayerRendererMixin {

    /**
     * Oyuncuyu küçültme ölçeği.
     * Düzeltme #10: Sabit belgelenmiş.
     *
     * Değer: 1 / 2.34 ≈ 0.427
     * Neden 2.34: MECCHA CHAMELEON oyunundaki karakter boyutunu taklit eder;
     * standart Minecraft karakterinin yaklaşık 2.34 katı küçülmesi,
     * sokakta gizlenebilecek boyuta karşılık gelir.
     */
    private static final float CHAMELEON_SCALE = 1f / 2.34f;

    /**
     * Render başlamadan önce:
     *   1. Karakteri CHAMELEON_SCALE oranında küçült (ayak tabanı pivot)
     *   2. Aktif poza göre eklem açılarını uygula
     */
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(AbstractClientPlayerEntity player, float yaw, float tickDelta,
                              MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                              int light, CallbackInfo ci) {

        matrices.scale(CHAMELEON_SCALE, CHAMELEON_SCALE, CHAMELEON_SCALE);

        ChameleonPose pose = PlayerPaintStore.getPose(player.getUuid());
        PlayerEntityRenderer self = (PlayerEntityRenderer)(Object)this;
        @SuppressWarnings("unchecked")
        PlayerEntityModel<AbstractClientPlayerEntity> model =
                (PlayerEntityModel<AbstractClientPlayerEntity>) self.getModel();

        resetPose(model);

        switch (pose) {
            case PRONE        -> applyProne(matrices, model);
            case SIDE_LAY     -> applySideLay(matrices, model);
            case CROUCH_CUSTOM-> applyCrouchCustom(model);
            case FETAL        -> applyFetal(matrices, model);
            case WALL_HUG     -> applyWallHug(matrices, model);
            default           -> { /* STAND — varsayılan dik duruş */ }
        }
    }

    /**
     * Texture'ı dinamik beyaz + boyalı versiyonla değiştir.
     * Düzeltme #7: WhiteSkinManager.cleanup() artık PLAYER_LEAVE paketi
     * ile tetikleniyor; bellek sızıntısı giderildi.
     */
    @Inject(method = "getTexture(Lnet/minecraft/client/network/AbstractClientPlayerEntity;)Lnet/minecraft/util/Identifier;",
            at = @At("RETURN"), cancellable = true)
    private void overrideSkinTexture(AbstractClientPlayerEntity player,
                                     CallbackInfoReturnable<Identifier> cir) {
        PaintData data = PlayerPaintStore.getPaint(player.getUuid());
        Identifier dynamicId = WhiteSkinManager.getTexture(player.getUuid(), data);
        cir.setReturnValue(dynamicId);
    }

    // ── Poz yardımcıları ──────────────────────────────────────────────────────

    private void resetPose(PlayerEntityModel<AbstractClientPlayerEntity> m) {
        m.head.pitch = 0; m.head.roll  = 0; m.head.yaw   = 0;
        m.body.pitch = 0; m.body.roll  = 0;
        m.rightArm.pitch = 0; m.rightArm.roll = 0;
        m.leftArm.pitch  = 0; m.leftArm.roll  = 0;
        m.rightLeg.pitch = 0; m.leftLeg.pitch = 0;
    }

    /** Yüzüstü yatma */
    private void applyProne(MatrixStack mx, PlayerEntityModel<AbstractClientPlayerEntity> m) {
        mx.translate(0, -0.6, 0.4);
        mx.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90f));
        m.head.pitch = rad(-90);
        m.rightArm.pitch = rad(-20); m.rightArm.roll = rad(20);
        m.leftArm.pitch  = rad(-20); m.leftArm.roll  = rad(-20);
    }

    /** Yan yatma */
    private void applySideLay(MatrixStack mx, PlayerEntityModel<AbstractClientPlayerEntity> m) {
        mx.translate(0.3, -0.55, 0);
        mx.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-90f));
        m.rightArm.pitch = rad(-15); m.leftArm.pitch  = rad(15);
        m.rightLeg.pitch = rad(-10); m.leftLeg.pitch  = rad(10);
    }

    /** Özel derin çömelme */
    private void applyCrouchCustom(PlayerEntityModel<AbstractClientPlayerEntity> m) {
        m.body.pitch = rad(35); m.head.pitch  = rad(-25);
        m.rightArm.pitch = rad(-65); m.leftArm.pitch  = rad(-65);
        m.rightLeg.pitch = rad(55);  m.leftLeg.pitch  = rad(55);
    }

    /** Fetal — top gibi kıvrıl */
    private void applyFetal(MatrixStack mx, PlayerEntityModel<AbstractClientPlayerEntity> m) {
        mx.translate(0, -0.35, 0.25);
        mx.multiply(RotationAxis.POSITIVE_X.rotationDegrees(85f));
        m.body.pitch = rad(45); m.head.pitch = rad(45);
        m.rightArm.pitch = rad(90);  m.leftArm.pitch  = rad(90);
        m.rightLeg.pitch = rad(-130);m.leftLeg.pitch  = rad(-130);
    }

    /** Duvara yapış */
    private void applyWallHug(MatrixStack mx, PlayerEntityModel<AbstractClientPlayerEntity> m) {
        mx.translate(0, 0, -0.25);
        mx.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-18f));
        m.head.pitch = rad(10); m.body.pitch = rad(-10);
        m.rightArm.pitch = rad(-175); m.rightArm.roll = rad(35);
        m.leftArm.pitch  = rad(-175); m.leftArm.roll  = rad(-35);
    }

    private static float rad(float deg) { return (float)Math.toRadians(deg); }
}
