package com.chameleon.mixin;

import com.chameleon.client.WhiteSkinManager;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * FIX 1 & 2: Render etkileri ARTIK role göre uygulanıyor.
 *
 *  NONE   → Hiçbir şey değişmez: normal skin, normal boyut
 *  HIDER  → Küçük (1/2.34x) + boyalı/beyaz skin
 *  SEEKER → Normal boyut + boyalı/beyaz skin
 *
 * Not: Birinci şahıs (F5'siz) görünüm değişmez — bu Minecraft'ın normal
 *       davranışıdır. F5 veya diğer oyuncuların bakışından efekt görünür.
 */
@Environment(EnvType.CLIENT)
@Mixin(PlayerEntityRenderer.class)
public class PlayerRendererMixin {

    /**
     * FIX 10: CHAMELEON_SCALE — Düzeltme #2 ile belgelendi.
     * Saklananları küçültür (normal boyutun ~%43'ü).
     */
    private static final float CHAMELEON_SCALE = 1f / 2.34f;

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(AbstractClientPlayerEntity player, float yaw, float tickDelta,
                              MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                              int light, CallbackInfo ci) {

        RoleManager.Role role = RoleManager.getRole(player.getUuid());

        switch (role) {
            case NONE -> {
                // FIX 2: NONE rolünde HİÇBİR DEĞİŞİKLİK YOK — normal Minecraft görünümü
                return;
            }
            case HIDER -> {
                // Küçük: pivot ayaktan (origin) scale — ayaklar yerde kalır
                matrices.scale(CHAMELEON_SCALE, CHAMELEON_SCALE, CHAMELEON_SCALE);
            }
            case SEEKER -> {
                // Normal boyut — sadece skin değişir (getTexture override aşağıda)
                // Scale değişmiyor
            }
        }
        // Poz uygulaması PlayerModelMixin içinde (setAngles sonrası)
    }

    /**
     * FIX 1 & 2: Skin texture SADECE HIDER veya SEEKER rolünde override edilir.
     * NONE rolünde oyuncunun kendi orjinal skini gösterilir.
     */
    @Inject(
        method = "getTexture(Lnet/minecraft/client/network/AbstractClientPlayerEntity;)Lnet/minecraft/util/Identifier;",
        at = @At("RETURN"),
        cancellable = true
    )
    private void overrideSkinTexture(AbstractClientPlayerEntity player,
                                     CallbackInfoReturnable<Identifier> cir) {

        RoleManager.Role role = RoleManager.getRole(player.getUuid());

        // FIX 2: NONE rolünde kendi skini → override yok
        if (role == RoleManager.Role.NONE) return;

        // HIDER veya SEEKER: boyalı beyaz skin
        PaintData data = PlayerPaintStore.getPaint(player.getUuid());
        Identifier dynamicId = WhiteSkinManager.getTexture(player.getUuid(), data);
        cir.setReturnValue(dynamicId);
    }
}
