package com.chameleon.network;

import com.chameleon.ChameleonMod;
import com.chameleon.paint.PaintData;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

/**
 * Ağ paketleri:
 *
 *  C→S  PAINT_STROKE  : fırça darbesi (cx, cy, radius, color)
 *  C→S  POSE_CHANGE   : poz değişikliği (poseId)
 *  S→C  SYNC_PAINT    : tüm boya verisi (uuid + int[])
 *  S→C  SYNC_POSE     : poz senkronu (uuid + poseId)
 *  S→C  SYNC_ROLE     : rol senkronu (uuid + roleId)
 *  S→C  PLAYER_LEAVE  : oyuncu ayrıldı, texture temizle (uuid)
 */
public class ChameleonNetwork {

    // Paket kimlikleri
    public static final Identifier PAINT_STROKE  = new Identifier(ChameleonMod.MOD_ID, "paint_stroke");
    public static final Identifier POSE_CHANGE   = new Identifier(ChameleonMod.MOD_ID, "pose_change");
    public static final Identifier SYNC_PAINT    = new Identifier(ChameleonMod.MOD_ID, "sync_paint");
    public static final Identifier SYNC_POSE     = new Identifier(ChameleonMod.MOD_ID, "sync_pose");
    public static final Identifier SYNC_ROLE     = new Identifier(ChameleonMod.MOD_ID, "sync_role");
    public static final Identifier PLAYER_LEAVE  = new Identifier(ChameleonMod.MOD_ID, "player_leave");

    public static void registerServerPackets() {

        // ── C→S: Fırça darbesi ───────────────────────────────────────────────
        // Düzeltme #6: Sunucu her zaman paketin GÖNDERENİNİN UUID'ini kullanır.
        // Bir oyuncu asla başkasının boyama verisine yazamaz.
        ServerPlayNetworking.registerGlobalReceiver(PAINT_STROKE,
                (server, player, handler, buf, responseSender) -> {
                    int cx     = buf.readInt();
                    int cy     = buf.readInt();
                    int radius = buf.readInt();
                    int color  = buf.readInt();

                    server.execute(() -> {
                        // UUID, paketin göndericisinden alınır → başkasına boyama imkânsız
                        PaintData data = PlayerPaintStore.getPaint(player);
                        data.paintBrush(cx, cy, radius, color);
                        broadcastPaintSync(player.getUuid(), data, handler);
                    });
                });

        // ── C→S: Poz değiştirme ───────────────────────────────────────────────
        ServerPlayNetworking.registerGlobalReceiver(POSE_CHANGE,
                (server, player, handler, buf, responseSender) -> {
                    int poseId = buf.readInt();

                    server.execute(() -> {
                        ChameleonPose pose = ChameleonPose.byId(poseId);
                        PlayerPaintStore.setPose(player.getUuid(), pose);
                        broadcastPoseSync(player.getUuid(), pose, handler);
                    });
                });
    }

    // ── Yayın yardımcıları ────────────────────────────────────────────────────

    /**
     * Boya datasını tüm oyunculara yayınla.
     * Düzeltme #1: Tutarlı writeIntArray → istemcide readIntArray ile eşleşir.
     */
    public static void broadcastPaintSync(java.util.UUID uuid, PaintData data,
                                          net.minecraft.server.network.ServerPlayNetworkHandler origin) {
        if (origin.getPlayer().getServer() == null) return;
        int[] cells = data.getRawCells();
        origin.getPlayer().getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(uuid);
            buf.writeIntArray(cells);   // ← writeIntArray: istemci readIntArray bekliyor
            ServerPlayNetworking.send(p, SYNC_PAINT, buf);
        });
    }

    /** Poz senkronunu tüm oyunculara yayınla. */
    public static void broadcastPoseSync(java.util.UUID uuid, ChameleonPose pose,
                                         net.minecraft.server.network.ServerPlayNetworkHandler origin) {
        if (origin.getPlayer().getServer() == null) return;
        origin.getPlayer().getServer().getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(uuid);
            buf.writeInt(pose.id);
            ServerPlayNetworking.send(p, SYNC_POSE, buf);
        });
    }

    /** Oyuncu ayrılma bildirimini tüm istemcilere yayınla (texture temizleme için). */
    public static void broadcastPlayerLeave(java.util.UUID uuid,
                                            net.minecraft.server.MinecraftServer server) {
        if (server == null) return;
        server.getPlayerManager().getPlayerList().forEach(p -> {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeUuid(uuid);
            ServerPlayNetworking.send(p, PLAYER_LEAVE, buf);
        });
    }

    // ── Paket oluşturucular (JOIN senkronu için) ──────────────────────────────

    /** SYNC_PAINT paketi oluştur. */
    public static PacketByteBuf buildSyncPaintPacket(java.util.UUID uuid, PaintData data) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(uuid);
        buf.writeIntArray(data.getRawCells());
        return buf;
    }

    /** SYNC_POSE paketi oluştur. */
    public static PacketByteBuf buildSyncPosePacket(java.util.UUID uuid, ChameleonPose pose) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(uuid);
        buf.writeInt(pose.id);
        return buf;
    }

    /** SYNC_ROLE paketi oluştur. */
    public static PacketByteBuf buildSyncRolePacket(java.util.UUID uuid,
                                                    com.chameleon.role.RoleManager.Role role) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(uuid);
        buf.writeInt(role.id);
        return buf;
    }
}
