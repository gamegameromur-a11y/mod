package com.chameleon.paint;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIntArray;

import java.util.Arrays;

/**
 * Oyuncunun boyama verisini tutar.
 * Karakter 32x64 hücreye bölünmüş (Steve texture oranı).
 * Her hücre bir ARGB int renk değeri.
 * Varsayılan renk: beyaz (0xFFFFFFFF)
 */
public class PaintData {

    public static final int GRID_W = 32;
    public static final int GRID_H = 64;
    public static final int CELL_COUNT = GRID_W * GRID_H;

    // Her hücrenin ARGB rengi — varsayılan beyaz
    private final int[] cells;

    public PaintData() {
        cells = new int[CELL_COUNT];
        Arrays.fill(cells, 0xFFFFFFFF); // tamamen beyaz
    }

    private PaintData(int[] cells) {
        this.cells = cells;
    }

    /** Tek bir hücrenin rengini al */
    public int getCell(int x, int y) {
        if (x < 0 || x >= GRID_W || y < 0 || y >= GRID_H) return 0xFFFFFFFF;
        return cells[y * GRID_W + x];
    }

    /**
     * Belirli bir merkez etrafında dairesel fırça ile boya.
     * radius: hücre cinsinden yarıçap (1-10 arası önerilen)
     */
    public void paintBrush(int centerX, int centerY, int radius, int argbColor) {
        for (int dy = -radius; dy <= radius; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                if (dx * dx + dy * dy <= radius * radius) {
                    int cx = centerX + dx;
                    int cy = centerY + dy;
                    if (cx >= 0 && cx < GRID_W && cy >= 0 && cy < GRID_H) {
                        cells[cy * GRID_W + cx] = argbColor;
                    }
                }
            }
        }
    }

    /** Tüm boyamayı beyaza sıfırla */
    public void reset() {
        Arrays.fill(cells, 0xFFFFFFFF);
    }

    /** NBT'ye kaydet (sunucu→istemci sync ve persist için) */
    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.put("cells", new NbtIntArray(cells));
        return nbt;
    }

    /** NBT'den yükle */
    public static PaintData fromNbt(NbtCompound nbt) {
        if (nbt.contains("cells")) {
            int[] loaded = nbt.getIntArray("cells");
            if (loaded.length == CELL_COUNT) {
                return new PaintData(loaded.clone());
            }
        }
        return new PaintData();
    }

    /** Ağ üzerinden göndermek için ham int dizisi */
    public int[] getRawCells() {
        return cells.clone();
    }

    /** Ham dizi ile oluştur (ağdan gelince) */
    public static PaintData fromRaw(int[] raw) {
        if (raw.length != CELL_COUNT) return new PaintData();
        return new PaintData(raw.clone());
    }
}
