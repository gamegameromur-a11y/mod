package com.chameleon.paint;

import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.RoleManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * HATA #3 DÜZELTMESİ — Rol artık NBT'ye kaydediliyor.
 *
 * Eski kod: savePlayer() poz ve boyayı kaydediyordu ama rolü unutuyordu.
 * Sonuç: sunucudan çıkıp girince rol NONE'a dönüyordu.
 *
 * Artık rol de "role" anahtarıyla NBT'ye yazılıyor ve yükleniyor.
 */
public class PlayerPaintStore {

    private static final Map<UUID, PaintData>     paintMap = new ConcurrentHashMap<>();
    private static final Map<UUID, ChameleonPose> poseMap  = new ConcurrentHashMap<>();

    // ── Boya ─────────────────────────────────────────────────────────────────

    public static PaintData getPaint(PlayerEntity player) {
        return paintMap.computeIfAbsent(player.getUuid(), k -> new PaintData());
    }

    public static PaintData getPaint(UUID uuid) {
        return paintMap.computeIfAbsent(uuid, k -> new PaintData());
    }

    public static void setPaint(UUID uuid, PaintData data) { paintMap.put(uuid, data); }

    // ── Poz ──────────────────────────────────────────────────────────────────

    public static ChameleonPose getPose(PlayerEntity player) {
        return poseMap.getOrDefault(player.getUuid(), ChameleonPose.STAND);
    }

    public static ChameleonPose getPose(UUID uuid) {
        return poseMap.getOrDefault(uuid, ChameleonPose.STAND);
    }

    public static void setPose(UUID uuid, ChameleonPose pose) { poseMap.put(uuid, pose); }

    // ── Temizlik ─────────────────────────────────────────────────────────────

    public static void remove(UUID uuid) {
        paintMap.remove(uuid);
        poseMap.remove(uuid);
    }

    // ── NBT Persist ──────────────────────────────────────────────────────────

    /**
     * Boya + poz + ROL'ü NBT'ye kaydet.
     * HATA #3: "role" anahtarı eklendi.
     */
    public static NbtCompound savePlayer(UUID uuid) {
        NbtCompound nbt = new NbtCompound();
        nbt.put("paint", getPaint(uuid).toNbt());
        nbt.putInt("pose", getPose(uuid).id);
        // HATA #3 DÜZELTMESİ: rol kaydediliyordu
        nbt.putInt("role", RoleManager.getRole(uuid).id);
        return nbt;
    }

    /**
     * Boya + poz + ROL'ü NBT'den yükle.
     * HATA #3: "role" anahtarı okunuyor.
     */
    public static void loadPlayer(UUID uuid, NbtCompound nbt) {
        if (nbt.contains("paint")) setPaint(uuid, PaintData.fromNbt(nbt.getCompound("paint")));
        if (nbt.contains("pose"))  setPose(uuid, ChameleonPose.byId(nbt.getInt("pose")));
        // HATA #3 DÜZELTMESİ: rol yükleniyor
        if (nbt.contains("role"))  RoleManager.setRole(uuid, RoleManager.Role.byId(nbt.getInt("role")));
    }
}
