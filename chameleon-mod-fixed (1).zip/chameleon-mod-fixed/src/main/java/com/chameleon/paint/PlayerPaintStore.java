package com.chameleon.paint;

import com.chameleon.pose.ChameleonPose;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;   // Düzeltme #2: thread-safe

/**
 * Tüm oyuncuların boya + poz verilerini tutan merkezi depo.
 * Sunucuda ve istemcide ayrı ayrı tutulur; sync paketlerle eşleştirilir.
 *
 * Düzeltme #2: HashMap → ConcurrentHashMap (thread safety)
 */
public class PlayerPaintStore {

    private static final Map<UUID, PaintData>     paintMap = new ConcurrentHashMap<>();
    private static final Map<UUID, ChameleonPose> poseMap  = new ConcurrentHashMap<>();

    // ── Boya ─────────────────────────────────────────────────────────────────

    public static PaintData getPaint(PlayerEntity player) {
        return paintMap.computeIfAbsent(player.getUuid(), k -> new PaintData());
    }

    public static PaintData getPaint(UUID uuid) {
        return paintMap.computeIfAbsent(uuid, k -> new PaintData());
    }

    public static void setPaint(UUID uuid, PaintData data) {
        paintMap.put(uuid, data);
    }

    // ── Poz ──────────────────────────────────────────────────────────────────

    public static ChameleonPose getPose(PlayerEntity player) {
        return poseMap.getOrDefault(player.getUuid(), ChameleonPose.STAND);
    }

    public static ChameleonPose getPose(UUID uuid) {
        return poseMap.getOrDefault(uuid, ChameleonPose.STAND);
    }

    public static void setPose(UUID uuid, ChameleonPose pose) {
        poseMap.put(uuid, pose);
    }

    // ── Temizlik ─────────────────────────────────────────────────────────────

    public static void remove(UUID uuid) {
        paintMap.remove(uuid);
        poseMap.remove(uuid);
    }

    // ── NBT Persist (Düzeltme #4) ─────────────────────────────────────────────

    /**
     * Oyuncu verisini NBT'ye kaydet.
     * PlayerEntityMixin.writeCustomDataToNbt() tarafından otomatik çağrılır.
     */
    public static NbtCompound savePlayer(UUID uuid) {
        NbtCompound nbt = new NbtCompound();
        nbt.put("paint", getPaint(uuid).toNbt());
        nbt.putInt("pose", getPose(uuid).id);
        return nbt;
    }

    /**
     * Oyuncu verisini NBT'den yükle.
     * PlayerEntityMixin.readCustomDataFromNbt() tarafından otomatik çağrılır.
     */
    public static void loadPlayer(UUID uuid, NbtCompound nbt) {
        if (nbt.contains("paint")) {
            setPaint(uuid, PaintData.fromNbt(nbt.getCompound("paint")));
        }
        if (nbt.contains("pose")) {
            setPose(uuid, ChameleonPose.byId(nbt.getInt("pose")));
        }
    }
}
