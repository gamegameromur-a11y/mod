package com.chameleon;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.ChameleonCommand;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ChameleonMod implements ModInitializer {

    public static final String MOD_ID = "chameleon";
    public static final Logger LOGGER  = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Chameleon Mod yükleniyor...");

        ChameleonNetwork.registerServerPackets();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                ChameleonCommand.register(dispatcher));

        // ── JOIN: katılan oyuncuya + diğerlerine veri senkronu ───────────────
        // HATA #9 DÜZELTMESİ: tek döngüde hem "diğerleri → katılan" hem de
        // "katılan → diğerleri" işleniyor (önceden 2 ayrı döngüydü).
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity joined = handler.getPlayer();
            List<ServerPlayerEntity> all = server.getPlayerManager().getPlayerList();

            all.forEach(other -> {
                if (other.getUuid().equals(joined.getUuid())) {
                    // Kendi verilerini al (reconnect desteği)
                    ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_PAINT,
                            ChameleonNetwork.buildSyncPaintPacket(joined.getUuid(), PlayerPaintStore.getPaint(joined.getUuid())));
                    ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_POSE,
                            ChameleonNetwork.buildSyncPosePacket(joined.getUuid(), PlayerPaintStore.getPose(joined.getUuid())));
                    ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_ROLE,
                            ChameleonNetwork.buildSyncRolePacket(joined.getUuid(), RoleManager.getRole(joined.getUuid())));
                } else {
                    // Diğer oyuncunun verisini katılana gönder
                    ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_PAINT,
                            ChameleonNetwork.buildSyncPaintPacket(other.getUuid(), PlayerPaintStore.getPaint(other.getUuid())));
                    ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_POSE,
                            ChameleonNetwork.buildSyncPosePacket(other.getUuid(), PlayerPaintStore.getPose(other.getUuid())));
                    ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_ROLE,
                            ChameleonNetwork.buildSyncRolePacket(other.getUuid(), RoleManager.getRole(other.getUuid())));

                    // Katılanın verisini diğerine gönder
                    ServerPlayNetworking.send(other, ChameleonNetwork.SYNC_PAINT,
                            ChameleonNetwork.buildSyncPaintPacket(joined.getUuid(), PlayerPaintStore.getPaint(joined.getUuid())));
                    ServerPlayNetworking.send(other, ChameleonNetwork.SYNC_POSE,
                            ChameleonNetwork.buildSyncPosePacket(joined.getUuid(), PlayerPaintStore.getPose(joined.getUuid())));
                    ServerPlayNetworking.send(other, ChameleonNetwork.SYNC_ROLE,
                            ChameleonNetwork.buildSyncRolePacket(joined.getUuid(), RoleManager.getRole(joined.getUuid())));
                }
            });
        });

        // ── DISCONNECT: texture temizleme paketi ─────────────────────────────
        // HATA #4 DÜZELTMESİ: leaving oyuncu hariç gönder.
        // Önceki kod ayrılan oyuncuya da PLAYER_LEAVE gönderiyordu;
        // bağlantısı kesilirken paketi alırsa NullPointer ya da çöküş riski.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity leaving = handler.getPlayer();
            server.getPlayerManager().getPlayerList().forEach(other -> {
                // HATA #4: ayrılan oyuncuyu filtrele
                if (other.getUuid().equals(leaving.getUuid())) return;
                var buf = net.fabricmc.fabric.api.networking.v1.PacketByteBufs.create();
                buf.writeUuid(leaving.getUuid());
                ServerPlayNetworking.send(other, ChameleonNetwork.PLAYER_LEAVE, buf);
            });
        });

        LOGGER.info("Chameleon Mod hazır!");
    }
}
