package com.chameleon;

import com.chameleon.network.ChameleonNetwork;
import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.pose.ChameleonPose;
import com.chameleon.role.ChameleonCommand;
import com.chameleon.role.RoleManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChameleonMod implements ModInitializer {

    public static final String MOD_ID = "chameleon";
    public static final Logger LOGGER  = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Chameleon Mod yükleniyor...");

        // ── Sunucu paketlerini kaydet ────────────────────────────────────────
        ChameleonNetwork.registerServerPackets();

        // ── Komutları kaydet ─────────────────────────────────────────────────
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                ChameleonCommand.register(dispatcher));

        // ── Oyuncu bağlantı olayları ──────────────────────────────────────────

        // Düzeltme #3: onSpawn yerine ServerPlayConnectionEvents.JOIN kullanılıyor.
        // Bu event hem ilk bağlanmada hem reconnect'te tetiklenir.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity joined = handler.getPlayer();

            // 1. Katılan oyuncuya diğer herkesin verilerini gönder
            server.getPlayerManager().getPlayerList().forEach(other -> {
                if (other.getUuid().equals(joined.getUuid())) return;

                // Boya + poz
                ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_PAINT,
                        ChameleonNetwork.buildSyncPaintPacket(other.getUuid(),
                                PlayerPaintStore.getPaint(other.getUuid())));
                ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_POSE,
                        ChameleonNetwork.buildSyncPosePacket(other.getUuid(),
                                PlayerPaintStore.getPose(other.getUuid())));

                // Rol senkronu
                ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_ROLE,
                        ChameleonNetwork.buildSyncRolePacket(other.getUuid(),
                                RoleManager.getRole(other.getUuid())));
            });

            // 2. Katılan oyuncuya kendi verilerini de gönder (reconnect desteği)
            ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_PAINT,
                    ChameleonNetwork.buildSyncPaintPacket(joined.getUuid(),
                            PlayerPaintStore.getPaint(joined.getUuid())));
            ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_POSE,
                    ChameleonNetwork.buildSyncPosePacket(joined.getUuid(),
                            PlayerPaintStore.getPose(joined.getUuid())));
            ServerPlayNetworking.send(joined, ChameleonNetwork.SYNC_ROLE,
                    ChameleonNetwork.buildSyncRolePacket(joined.getUuid(),
                            RoleManager.getRole(joined.getUuid())));

            // 3. Diğer oyunculara yeni katılanın verilerini bildir
            server.getPlayerManager().getPlayerList().forEach(other -> {
                if (other.getUuid().equals(joined.getUuid())) return;

                ServerPlayNetworking.send(other, ChameleonNetwork.SYNC_PAINT,
                        ChameleonNetwork.buildSyncPaintPacket(joined.getUuid(),
                                PlayerPaintStore.getPaint(joined.getUuid())));
                ServerPlayNetworking.send(other, ChameleonNetwork.SYNC_POSE,
                        ChameleonNetwork.buildSyncPosePacket(joined.getUuid(),
                                PlayerPaintStore.getPose(joined.getUuid())));
                ServerPlayNetworking.send(other, ChameleonNetwork.SYNC_ROLE,
                        ChameleonNetwork.buildSyncRolePacket(joined.getUuid(),
                                RoleManager.getRole(joined.getUuid())));
            });
        });

        // Düzeltme #7: Oyuncu ayrılınca tüm istemcilere PLAYER_LEAVE paketi gönder.
        // İstemciler bu paketi alınca WhiteSkinManager.cleanup(uuid) çağırır.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity leaving = handler.getPlayer();
            // Texture temizleme paketi (PlayerEntityMixin.onDisconnect'ten önce çalışır)
            ChameleonNetwork.broadcastPlayerLeave(leaving.getUuid(), server);
        });

        LOGGER.info("Chameleon Mod hazır!");
    }
}
