package com.chameleon.mixin;

import com.chameleon.paint.PlayerPaintStore;
import com.chameleon.role.RoleManager;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerPlayerEntity.class)
public class PlayerEntityMixin {

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onLoadNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        if (nbt.contains("ChameleonData")) {
            PlayerPaintStore.loadPlayer(self.getUuid(), nbt.getCompound("ChameleonData"));
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onSaveNbt(NbtCompound nbt, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        nbt.put("ChameleonData", PlayerPaintStore.savePlayer(self.getUuid()));
    }

    /**
     * 1.20.1 Yarn mapping'de düşme hasarı metodu:
     * handleFallDamage → takeDamage ile DamageType.FALL kombinasyonu
     * Doğru yol: LivingEntity#handleFallDamage yerine
     * PlayerEntity'deki damage event'ini kullanmak.
     *
     * Şimdilik bu mixin'i tamamen kaldırıyoruz,
     * düşme hasarı engeli ChameleonMod'daki ServerLivingEntityEvents.ALLOW_DAMAGE
     * ile yapılacak — mixin gerekmez.
     */

    @Inject(method = "onDisconnect", at = @At("TAIL"))
    private void onPlayerLeave(CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity)(Object)this;
        PlayerPaintStore.remove(self.getUuid());
        RoleManager.remove(self.getUuid());
    }
}
